'use client';

import React from 'react';
import { HeroEvent } from '@/components/terminal/HeroEvent';
import { MacroReasoningChain } from '@/components/terminal/MacroReasoningChain';
import { CrossAssetImpactMap } from '@/components/terminal/CrossAssetImpactMap';
import { DecisionEngine } from '@/components/terminal/DecisionEngine';
import { RiskEngine } from '@/components/terminal/RiskEngine';
import { ExecutionPanel } from '@/components/terminal/ExecutionPanel';
import { MarketContext } from '@/components/terminal/MarketContext';
import { LiveTradeTape } from '@/components/terminal/LiveTradeTape';
import { AgentTrace } from '@/components/terminal/AgentTrace';
import { EventStream } from '@/components/terminal/EventStream';
import { SectionRule } from '@/components/common/SectionRule';

export default function TerminalPage() {
  return (
    <div className="space-y-8 pb-12">
      {/* Terminal Title Banner */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              INSTITUTIONAL INTELLIGENCE INTERFACE
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              TERMINAL
            </h1>
          </div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest text-right">
            <span>REAL-TIME MACRO TRANSMISSION & RISK-AWARE EXECUTION</span>
          </div>
        </div>
      </div>

      {/* 01. Dominant Hero Event */}
      <HeroEvent />

      {/* Section Divider */}
      <SectionRule
        thickness={8}
        title="01 // MACRO REASONING & TRANSMISSION"
        meta="DETERMINISTIC CAUSALITY"
      />

      {/* 02. Macro Reasoning Chain */}
      <MacroReasoningChain />

      {/* 03. Cross-Asset Impact Map */}
      <CrossAssetImpactMap />

      {/* Section Divider */}
      <SectionRule
        thickness={8}
        title="02 // DECISION CORE & INDEPENDENT RISK"
        meta="PORTFOLIO DEFENSE FIRST"
      />

      {/* 04. AI Decision Engine */}
      <DecisionEngine />

      {/* 05. Independent Risk Engine & Gate */}
      <RiskEngine />

      {/* 06. Execution Panel & Paper Confirm */}
      <ExecutionPanel />

      {/* Section Divider */}
      <SectionRule
        thickness={4}
        title="03 // MARKET CONTEXT & AGENT TELEMETRY"
        meta="INTERMARKET HARMONIZATION"
      />

      {/* 07. Contextual Market Telemetry */}
      <MarketContext />

      {/* 08. Live Trade Tape & Agent Trace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <LiveTradeTape />
        <AgentTrace />
      </div>

      {/* Section Divider */}
      <SectionRule
        thickness={4}
        title="04 // GLOBAL MACRO STREAM"
        meta="CONTINUOUS MONITORING"
      />

      {/* 09. Event Stream */}
      <EventStream />
    </div>
  );
}
