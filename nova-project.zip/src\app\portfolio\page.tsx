'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { SectionRule } from '@/components/common/SectionRule';
import { Shield, ArrowUpRight, ArrowDownRight, Minus, X } from 'lucide-react';

export function GeometricBar({ percent }: { percent: number }) {
  // Generates geometric block character string e.g. ██████
  const blocks = Math.round(percent / 4);
  const blockString = '█'.repeat(blocks);
  return (
    <div className="flex items-center gap-3 font-mono">
      <div className="text-black font-mono text-sm tracking-tight overflow-hidden">
        {blockString || '—'}
      </div>
      <span className="text-xs font-bold">{percent}%</span>
    </div>
  );
}

export default function PortfolioPage() {
  const { portfolio, closePosition } = useTerminal();

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              TREASURY & EXPOSURE MONITOR
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              PORTFOLIO
            </h1>
          </div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest text-right">
            <span>REAL-TIME CAPITAL RISK & ASSET ALLOCATION</span>
          </div>
        </div>
      </div>

      {/* Top Metrics Matrix */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-0 border-2 border-black divide-x divide-y lg:divide-y-0 divide-black bg-white">
        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            TOTAL EQUITY
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black text-black">
            ${portfolio.equity.toLocaleString()}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            AVAILABLE: ${portfolio.availableCapital.toLocaleString()}
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            OPEN RISK ALLOCATION
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black text-black">
            {portfolio.openRisk.toFixed(1)}%
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            MAX LIMIT: {portfolio.riskLimit.toFixed(1)}%
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            DAILY P&L
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black text-black flex items-center gap-2">
            <span>
              {portfolio.dailyPnL >= 0 ? '+' : ''}${portfolio.dailyPnL.toFixed(2)}
            </span>
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            SESSION NET RETURN
          </span>
        </div>

        <div className="p-6 bg-black text-white">
          <span className="font-mono text-xs uppercase tracking-widest text-white/70 block mb-2">
            RISK UTILIZATION
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black">
            {portfolio.riskUtilization}%
          </div>
          <span className="font-mono text-[10px] uppercase tracking-widest text-white/70 mt-1 block">
            STATUS: SAFE
          </span>
        </div>
      </div>

      {/* Section Divider */}
      <SectionRule
        thickness={8}
        title="01 // MONOCHROME GEOMETRIC RISK ALLOCATION"
        meta="STRICT EXPOSURE QUOTAS"
      />

      {/* Monochrome Geometric Risk Visualization */}
      <div className="border-2 border-black bg-white p-6 md:p-8">
        <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
          <div className="flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-widest">
            <Shield className="w-4 h-4 text-black" />
            <span>PORTFOLIO EXPOSURE BARS (GEOMETRIC DENSITY)</span>
          </div>
          <span className="font-mono text-xs text-muted-foreground uppercase">
            TARGET EXPOSURE DISCIPLINE
          </span>
        </div>

        <div className="space-y-6 font-mono">
          {portfolio.allocations.map((alloc) => (
            <div key={alloc.asset} className="border border-black p-4 bg-muted/20">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-black uppercase">{alloc.asset}</span>
                <span className="text-muted-foreground uppercase text-[10px]">
                  RISK ALLOCATED: ${alloc.riskUsd}
                </span>
              </div>
              <GeometricBar percent={alloc.weight} />
            </div>
          ))}
        </div>
      </div>

      {/* Section Divider */}
      <SectionRule
        thickness={4}
        title="02 // ACTIVE POSITIONS LEDGER"
        meta="MARK-TO-MARKET POSITIONS"
      />

      {/* Active Positions Table */}
      <div className="border-2 border-black bg-white">
        <table className="w-full text-left font-mono text-xs border-collapse">
          <thead>
            <tr className="border-b-2 border-black text-muted-foreground uppercase text-[10px] tracking-widest bg-muted/20">
              <th className="py-4 px-4">POSITION ID</th>
              <th className="py-4 px-4">CATALYST</th>
              <th className="py-4 px-4">ASSET</th>
              <th className="py-4 px-4 text-center">SIDE</th>
              <th className="py-4 px-4 text-right">ENTRY</th>
              <th className="py-4 px-4 text-right">CURRENT PRICE</th>
              <th className="py-4 px-4 text-right">STOP</th>
              <th className="py-4 px-4 text-right">TARGET</th>
              <th className="py-4 px-4 text-right">UNREALIZED P&L</th>
              <th className="py-4 px-4 text-center">ACTION</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/10">
            {portfolio.positions.map((pos) => {
              const isOpen = pos.status === 'OPEN';
              return (
                <tr key={pos.id} className="hover:bg-muted/30 transition-colors">
                  <td className="py-4 px-4 text-muted-foreground font-bold">
                    {pos.id}
                  </td>
                  <td className="py-4 px-4 font-bold text-black">
                    {pos.eventTitle}
                  </td>
                  <td className="py-4 px-4 font-bold text-black">
                    {pos.asset}
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className="inline-block px-2 py-0.5 font-bold uppercase border border-black bg-black text-white text-[10px]">
                      {pos.side}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-black">
                    ${pos.entry.toLocaleString()}
                  </td>
                  <td className="py-4 px-4 text-right text-muted-foreground">
                    ${pos.currentPrice.toLocaleString()}
                  </td>
                  <td className="py-4 px-4 text-right text-muted-foreground">
                    ${pos.stop.toLocaleString()}
                  </td>
                  <td className="py-4 px-4 text-right text-muted-foreground">
                    ${pos.target.toLocaleString()}
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-black">
                    {pos.pnlPercent >= 0 ? '+' : ''}
                    {pos.pnlPercent.toFixed(2)}% (${pos.pnlUsd.toFixed(2)})
                  </td>
                  <td className="py-4 px-4 text-center">
                    {isOpen ? (
                      <button
                        onClick={() => closePosition(pos.id)}
                        className="px-2.5 py-1 border border-black bg-white hover:bg-black hover:text-white font-bold text-[10px] uppercase transition-colors"
                      >
                        CLOSE POSITION
                      </button>
                    ) : (
                      <span className="font-bold text-muted-foreground uppercase text-[10px]">
                        CLOSED
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
