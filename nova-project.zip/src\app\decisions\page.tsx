'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useTerminal } from '@/context/TerminalContext';
import { Filter, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function DecisionsPage() {
  const { decisions } = useTerminal();
  const [actionFilter, setActionFilter] = useState<'ALL' | 'LONG' | 'SHORT' | 'WAIT'>('ALL');

  const filteredDecisions = decisions.filter((dec) => {
    if (actionFilter === 'ALL') return true;
    return dec.action === actionFilter;
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Header */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              AUDITABLE AGENT LOG
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              DECISION JOURNAL
            </h1>
          </div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
            <span>FORENSIC VERIFICATION & ACCOUNTABILITY RECORD</span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-black pb-4">
        <div className="flex items-center gap-1 font-mono text-xs">
          <Filter className="w-3.5 h-3.5 text-black mr-2" />
          <span className="text-muted-foreground uppercase mr-2">ACTION:</span>
          {(['ALL', 'SHORT', 'LONG', 'WAIT'] as const).map((action) => (
            <button
              key={action}
              onClick={() => setActionFilter(action)}
              className={`px-3 py-1 uppercase tracking-wider font-bold border transition-colors ${
                actionFilter === action
                  ? 'bg-black text-white border-black'
                  : 'bg-white text-black border-transparent hover:border-black'
              }`}
            >
              {action}
            </button>
          ))}
        </div>

        <span className="font-mono text-xs text-muted-foreground uppercase">
          LOGGED DECISIONS: {filteredDecisions.length}
        </span>
      </div>

      {/* Decisions Table */}
      <div className="border-2 border-black bg-white">
        <table className="w-full text-left font-mono text-xs border-collapse">
          <thead>
            <tr className="border-b-2 border-black text-muted-foreground uppercase text-[10px] tracking-widest bg-muted/20">
              <th className="py-4 px-4">TIMESTAMP</th>
              <th className="py-4 px-4">EVENT CATALYST</th>
              <th className="py-4 px-4">TARGET ASSET</th>
              <th className="py-4 px-4 text-center">ACTION</th>
              <th className="py-4 px-4 text-right">CONFIDENCE</th>
              <th className="py-4 px-4 text-right">RISK %</th>
              <th className="py-4 px-4 text-center">RESULT / PNL</th>
              <th className="py-4 px-4 text-right">AUDIT DETAIL</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/10">
            {filteredDecisions.map((dec) => {
              const isWait = dec.action === 'WAIT';
              return (
                <tr key={dec.id} className="hover:bg-muted/30 transition-colors">
                  <td className="py-4 px-4 text-muted-foreground whitespace-nowrap">
                    {dec.timestamp}
                  </td>
                  <td className="py-4 px-4 font-bold text-black text-sm">
                    {dec.eventTitle}
                  </td>
                  <td className="py-4 px-4 font-bold text-black whitespace-nowrap">
                    {dec.asset}
                  </td>
                  <td className="py-4 px-4 text-center whitespace-nowrap">
                    <span
                      className={`inline-block px-3 py-1 font-mono font-bold uppercase tracking-wider text-xs border ${
                        isWait
                          ? 'border-black bg-white text-black'
                          : 'border-black bg-black text-white'
                      }`}
                    >
                      {dec.action}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-black whitespace-nowrap">
                    {dec.confidence}%
                  </td>
                  <td className="py-4 px-4 text-right whitespace-nowrap">
                    {dec.riskPercent > 0 ? `${dec.riskPercent.toFixed(1)}%` : '0.0%'}
                  </td>
                  <td className="py-4 px-4 text-center whitespace-nowrap">
                    <span className="font-bold uppercase text-[11px]">
                      {dec.status} {dec.pnl && `(${dec.pnl})`}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right whitespace-nowrap">
                    <Link
                      href={`/decisions/${dec.id}`}
                      className="inline-flex items-center gap-1.5 px-3 py-1 border border-black bg-white hover:bg-black hover:text-white font-bold transition-colors"
                    >
                      <span>INSPECT AUDIT</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
