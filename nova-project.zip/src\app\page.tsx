'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowRight, Terminal, Shield, Cpu, History } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';
import { useTerminal } from '@/context/TerminalContext';

export default function LandingPage() {
  const { portfolio, events } = useTerminal();

  const workflowSteps = [
    { num: '01', title: 'EVENT', desc: 'Continuous telemetry monitors CPI, FOMC, NFP, and global macro catalysts.' },
    { num: '02', title: 'INTERPRET', desc: 'Calculates statistical surprise vs consensus; parses macro significance.' },
    { num: '03', title: 'IMPACT', desc: 'Maps cross-asset propagation across USD, Treasuries, Equities, and Crypto.' },
    { num: '04', title: 'DECIDE', desc: 'Emits LONG / SHORT / WAIT directives with calibrated confidence metrics.' },
    { num: '05', title: 'RISK', desc: 'Independent 5-gate risk engine evaluates exposure, drawdown, and liquidity.' },
    { num: '06', title: 'EXECUTE', desc: 'Dispatches paper or live orders with deterministic stops and take-profits.' },
    { num: '07', title: 'LOG', desc: 'Records complete auditable trace: Event * Market * Risk = Decision.' },
  ];

  return (
    <div className="space-y-16 py-8 md:py-16">
      {/* Monumental Hero Section */}
      <section className="border-b-4 border-black pb-12 md:pb-16">
        <div className="max-w-5xl">
          <div className="flex items-center gap-3 font-mono text-xs uppercase tracking-widest text-muted-foreground mb-4">
            <span className="w-2.5 h-2.5 bg-black inline-block" />
            <span>INSTITUTIONAL QUANTITATIVE INTELLIGENCE</span>
          </div>

          <h1 className="font-display text-6xl sm:text-8xl lg:text-9xl font-black uppercase tracking-tight text-black leading-[0.85] mb-8">
            NOVA
          </h1>

          <div className="border-l-8 border-black pl-6 my-8">
            <h2 className="font-display text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-tight text-black leading-tight">
              WHEN THE EVENT HITS,
              <br />
              NOVA MOVES.
            </h2>
          </div>

          <p className="font-body text-xl sm:text-2xl text-black/85 max-w-3xl leading-relaxed mt-6">
            An autonomous event-driven trading agent that transforms market-moving macro releases into structured, risk-governed execution. Built on an austere, institutional decision engine.
          </p>

          <div className="flex flex-wrap items-center gap-4 mt-10">
            <Link
              href="/terminal"
              className="flex items-center gap-3 px-8 py-5 bg-black text-white font-mono text-xs font-black tracking-widest uppercase border-2 border-black hover:bg-white hover:text-black transition-colors"
            >
              <span>ENTER TERMINAL</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              href="/replay"
              className="flex items-center gap-3 px-8 py-5 bg-white text-black font-mono text-xs font-black tracking-widest uppercase border-2 border-black hover:bg-muted transition-colors"
            >
              <span>HISTORICAL REPLAY</span>
              <History className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Real-time System Metrics Bar */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-0 border-2 border-black divide-x divide-y md:divide-y-0 divide-black bg-white">
        <div className="p-6">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            ACCOUNT PORTFOLIO
          </span>
          <div className="font-mono text-3xl font-black text-black">
            ${portfolio.equity.toLocaleString()}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase">
            ACTIVE CAPITAL BASE
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            CURRENT OPEN RISK
          </span>
          <div className="font-mono text-3xl font-black text-black">
            {portfolio.openRisk.toFixed(1)}%
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase">
            CEILING: {portfolio.riskLimit}%
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            INDEXED MACRO EVENTS
          </span>
          <div className="font-mono text-3xl font-black text-black">
            {events.length}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase">
            MONITORED ANCHORS
          </span>
        </div>

        <div className="p-6 bg-black text-white">
          <span className="font-mono text-[10px] uppercase tracking-widest text-white/70 block mb-1">
            CORE PRINCIPLE
          </span>
          <div className="font-mono text-xl font-bold uppercase">
            ZERO-LOSS GATE
          </div>
          <span className="font-mono text-[10px] text-white/70 uppercase">
            RISK OVER OPINION
          </span>
        </div>
      </section>

      {/* Signature Section Rule */}
      <SectionRule
        thickness={8}
        title="THE 7-STAGE REASONING PIPELINE"
        meta="TRANSPARENT SYSTEM ARTIFACT"
      />

      {/* The 7-Stage Core Workflow Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {workflowSteps.map((step, idx) => {
          const isLast = idx === workflowSteps.length - 1;
          return (
            <div
              key={step.num}
              className={`border-2 p-6 flex flex-col justify-between ${
                isLast
                  ? 'border-black bg-black text-white md:col-span-2 lg:col-span-1'
                  : 'border-black bg-white text-black'
              }`}
            >
              <div>
                <span
                  className={`font-mono text-xs uppercase tracking-widest font-bold block mb-3 ${
                    isLast ? 'text-white/70' : 'text-muted-foreground'
                  }`}
                >
                  STAGE {step.num}
                </span>
                <h3
                  className={`font-display text-2xl font-black uppercase tracking-tight mb-2 ${
                    isLast ? 'text-white' : 'text-black'
                  }`}
                >
                  {step.title}
                </h3>
                <p
                  className={`font-body text-sm leading-relaxed ${
                    isLast ? 'text-white/80' : 'text-black/80'
                  }`}
                >
                  {step.desc}
                </p>
              </div>
            </div>
          );
        })}
      </section>

      {/* Section Divider */}
      <SectionRule
        thickness={4}
        title="FOUR INSTITUTIONAL PILLARS"
        meta="ARCHITECTURAL GUARANTEES"
      />

      {/* Four Pillars */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="border-2 border-black p-8 bg-white">
          <div className="flex items-center gap-3 mb-4">
            <Cpu className="w-6 h-6 text-black" />
            <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black">
              01 // EVENT INTELLIGENCE
            </h3>
          </div>
          <p className="font-body text-base text-black/80 leading-relaxed">
            The LLM is not merely a headline summarizer. It serves as the analytical reasoning layer calculating normalized statistical surprise, comparing actual vs expected prints, and modeling macroeconomic policy implications.
          </p>
        </div>

        <div className="border-2 border-black p-8 bg-white">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-black" />
            <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black">
              02 // INDEPENDENT RISK GATE
            </h3>
          </div>
          <p className="font-body text-base text-black/80 leading-relaxed">
            NOVA decouples signal conviction from portfolio execution. Even with 95% AI directional confidence, orders are unconditionally rejected if volatility is abnormal, liquidity is thin, or portfolio risk limits are reached.
          </p>
        </div>

        <div className="border-2 border-black p-8 bg-white">
          <div className="flex items-center gap-3 mb-4">
            <Terminal className="w-6 h-6 text-black" />
            <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black">
              03 // FULL DECISION TRACE
            </h3>
          </div>
          <p className="font-body text-base text-black/80 leading-relaxed">
            Every trade or WAIT directive preserves a complete forensic paper trail. The institutional audit equation: Event * Market * Risk = Decision ensures complete transparency and accountability during review.
          </p>
        </div>

        <div className="border-2 border-black p-8 bg-white">
          <div className="flex items-center gap-3 mb-4">
            <History className="w-6 h-6 text-black" />
            <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black">
              04 // HISTORICAL REPLAY
            </h3>
          </div>
          <p className="font-body text-base text-black/80 leading-relaxed">
            Re-run NOVA as if historic macro releases just hit the wires. Watch the agent detect anomalies, formulate thesis steps, check risk constraints, and execute within milliseconds on a forensic timeline.
          </p>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="border-4 border-black p-8 md:p-12 bg-black text-white text-center">
        <h2 className="font-display text-3xl sm:text-5xl font-black uppercase tracking-tight mb-4">
          LAUNCH NOVA TERMINAL
        </h2>
        <p className="font-body text-base sm:text-lg text-white/80 max-w-xl mx-auto mb-8">
          Step into the live event-driven autonomous trading environment. Analyze incoming catalysts or inject custom macro shocks.
        </p>
        <Link
          href="/terminal"
          className="inline-flex items-center gap-3 px-10 py-5 bg-white text-black font-mono text-xs font-black tracking-widest uppercase hover:bg-muted transition-colors"
        >
          <span>ENTER TERMINAL →</span>
        </Link>
      </section>
    </div>
  );
}
