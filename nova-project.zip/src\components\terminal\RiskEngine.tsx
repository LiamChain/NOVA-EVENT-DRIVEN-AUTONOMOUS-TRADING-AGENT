'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { Check, X, Shield, AlertTriangle } from 'lucide-react';

export function RiskEngine() {
  const { riskMetrics, riskGates, executionReady, blockReason, activeDecision } = useTerminal();

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            INDEPENDENT RISK ENGINE
          </h2>
        </div>
        <div className="flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-wider">
          <Shield className="w-4 h-4 text-black" />
          <span>PORTFOLIO SAFETY GATE</span>
        </div>
      </div>

      {/* Philosophy Callout */}
      <div className="border border-black p-4 mb-6 bg-muted/40 text-xs font-mono">
        <span className="font-bold text-black uppercase block mb-1">
          CAPITAL PRESERVATION PRINCIPLE
        </span>
        <p className="font-body text-xs text-black/80 leading-relaxed">
          NOVA will not trade simply because an AI model displays high directional conviction. All trades require strict multi-gate clearance across portfolio exposure, market liquidity, and statistical edge.
        </p>
      </div>

      {/* Quantitative Risk Metrics Table */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-0 border border-black divide-y sm:divide-y-0 sm:divide-x divide-black bg-white mb-6">
        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            ACCOUNT EQUITY
          </span>
          <div className="font-mono text-xl sm:text-2xl font-black text-black">
            ${riskMetrics.accountEquity.toLocaleString()}
          </div>
          <span className="font-mono text-[9px] text-muted-foreground uppercase">
            COLLATERAL BASE
          </span>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            MAX RISK / TRADE
          </span>
          <div className="font-mono text-xl sm:text-2xl font-bold text-black">
            {riskMetrics.maxPortfolioRiskPercent.toFixed(1)}%
          </div>
          <span className="font-mono text-[9px] text-muted-foreground uppercase">
            MANDATORY CEILING
          </span>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            PROPOSED RISK
          </span>
          <div className="font-mono text-xl sm:text-2xl font-black text-black">
            {riskMetrics.proposedRiskPercent.toFixed(1)}%
          </div>
          <span className="font-mono text-[9px] text-muted-foreground uppercase">
            ${riskMetrics.expectedLossUsd.toLocaleString()} MAX LOSS
          </span>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            POSITION SIZE
          </span>
          <div className="font-mono text-xl sm:text-2xl font-black text-black">
            ${riskMetrics.positionSizeUsd.toLocaleString()}
          </div>
          <span className="font-mono text-[9px] text-muted-foreground uppercase">
            R:R {riskMetrics.riskRewardRatio}
          </span>
        </div>
      </div>

      {/* The 5-Gate Checklist & Execution Status */}
      <div className="border-2 border-black p-5 bg-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4 mb-4">
          <div>
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block">
              SYSTEM GATE VERIFICATION
            </span>
            <span className="font-display text-lg font-black uppercase text-black">
              MULTI-FACTOR DECISION GATE
            </span>
          </div>

          <div
            className={`px-4 py-2 text-xs font-mono font-black tracking-widest uppercase border-2 flex items-center gap-2 ${
              executionReady
                ? 'bg-black text-white border-black'
                : 'bg-white text-black border-black'
            }`}
          >
            {executionReady ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>EXECUTION READY</span>
              </>
            ) : (
              <>
                <X className="w-4 h-4 text-black" />
                <span>EXECUTION BLOCKED</span>
              </>
            )}
          </div>
        </div>

        {/* 5 Gate Rows */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-2 font-mono text-xs">
          {riskGates.map((gate) => (
            <div
              key={gate.id}
              className={`p-3 border flex flex-col justify-between ${
                gate.passed ? 'border-black bg-muted/20' : 'border-black bg-black text-white'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] uppercase tracking-wider font-bold ${gate.passed ? 'text-muted-foreground' : 'text-white/80'}`}>
                  {gate.label}
                </span>
                <span className={`w-4 h-4 flex items-center justify-center border ${gate.passed ? 'border-black text-black font-bold' : 'border-white text-white font-bold'}`}>
                  {gate.passed ? '✓' : '✕'}
                </span>
              </div>
              <div>
                <div className={`font-bold text-sm ${gate.passed ? 'text-black' : 'text-white'}`}>
                  {gate.value}
                </div>
                <div className={`text-[9px] mt-1 line-clamp-2 ${gate.passed ? 'text-muted-foreground' : 'text-white/70'}`}>
                  {gate.detail}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Warning if blocked */}
        {!executionReady && (
          <div className="mt-4 p-3 border border-black bg-muted text-black font-mono text-xs flex items-center gap-3">
            <AlertTriangle className="w-4 h-4 text-black shrink-0" />
            <span>GATE RESTRICTION: {blockReason || 'Conditions did not satisfy minimum parameters.'}</span>
          </div>
        )}
      </div>
    </div>
  );
}
