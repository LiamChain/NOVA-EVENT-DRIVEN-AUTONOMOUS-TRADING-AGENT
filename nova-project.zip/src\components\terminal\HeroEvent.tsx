'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowUpRight, ArrowDownRight, Minus, AlertCircle } from 'lucide-react';

export function HeroEvent() {
  const { activeEvent, activeDecision } = useTerminal();

  const isSurprisePositive = activeEvent.surpriseNum > 0;
  const isSurpriseNegative = activeEvent.surpriseNum < 0;

  return (
    <section className="border-2 border-black bg-white p-6 md:p-8 relative">
      {/* Top Meta Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-black pb-4 text-xs font-mono tracking-widest uppercase">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <span className="font-bold text-black">PRIMARY MACRO CATALYST</span>
          <span className="text-muted-foreground">|</span>
          <span className="text-black font-semibold">{activeEvent.category}</span>
        </div>
        <div className="flex items-center gap-4 text-muted-foreground">
          <span>DATE: {activeEvent.date}</span>
          <span>RELEASE: {activeEvent.time} UTC</span>
          <span className="border border-black px-2 py-0.5 text-black font-bold">
            {activeEvent.importance}
          </span>
        </div>
      </div>

      {/* Main Hero Header */}
      <div className="mt-6 flex flex-col xl:flex-row xl:items-end justify-between gap-6">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
            SCHEDULED RELEASE
          </span>
          <h1 className="font-display text-4xl sm:text-6xl lg:text-7xl font-black uppercase tracking-tight text-black leading-none">
            {activeEvent.title}
          </h1>
        </div>

        {/* Editorial Statement */}
        <div className="border-l-4 border-black pl-4 xl:max-w-md">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block">
            NOVA ASSESSMENT
          </span>
          <h2 className="font-display text-2xl sm:text-3xl font-bold uppercase tracking-tight text-black">
            {activeEvent.headlineStatement}
          </h2>
          <div className="mt-1 flex items-center gap-3 font-mono text-xs">
            <span className="font-bold bg-black text-white px-2 py-0.5 uppercase">
              {activeEvent.macroBias}
            </span>
            <span className="text-muted-foreground">
              CONFIDENCE {activeDecision.confidence}%
            </span>
          </div>
        </div>
      </div>

      {/* Metric Columns (ACTUAL / EXPECTED / PREVIOUS / SURPRISE) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-0 mt-8 border-t-2 border-b-2 border-black">
        {/* ACTUAL */}
        <div className="p-4 sm:p-6 border-r border-b lg:border-b-0 border-black bg-white">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            ACTUAL
          </span>
          <div className="font-mono text-3xl sm:text-5xl font-black text-black tracking-tight">
            {activeEvent.actual}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest mt-1 block">
            BUREAU RELEASE DATA
          </span>
        </div>

        {/* EXPECTED */}
        <div className="p-4 sm:p-6 border-b lg:border-b-0 lg:border-r border-black bg-white">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            EXPECTED
          </span>
          <div className="font-mono text-3xl sm:text-5xl font-bold text-muted-foreground tracking-tight">
            {activeEvent.expected}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest mt-1 block">
            CONSENSUS SURVEY
          </span>
        </div>

        {/* PREVIOUS */}
        <div className="p-4 sm:p-6 border-r border-black bg-white">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            PREVIOUS
          </span>
          <div className="font-mono text-3xl sm:text-5xl font-bold text-muted-foreground tracking-tight">
            {activeEvent.previous}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest mt-1 block">
            PRIOR PERIOD REVISED
          </span>
        </div>

        {/* SURPRISE */}
        <div className="p-4 sm:p-6 bg-black text-white">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground text-white/80 block mb-2">
            SURPRISE SPREAD
          </span>
          <div className="font-mono text-3xl sm:text-5xl font-black tracking-tight flex items-center gap-2">
            {activeEvent.surprise}
            {isSurprisePositive && <ArrowUpRight className="w-8 h-8 text-white stroke-[2.5]" />}
            {isSurpriseNegative && <ArrowDownRight className="w-8 h-8 text-white stroke-[2.5]" />}
            {!isSurprisePositive && !isSurpriseNegative && <Minus className="w-8 h-8 text-white stroke-[2.5]" />}
          </div>
          <span className="font-mono text-[10px] uppercase tracking-widest text-white/70 mt-1 block">
            DELTA VS CONSENSUS
          </span>
        </div>
      </div>

      {/* Intelligence Editorial Breakdown (WHAT HAPPENED? / WHAT DOES IT MEAN?) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        <div className="border border-black p-6 bg-muted/30">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 bg-black inline-block" />
            <h3 className="font-display text-xl font-black uppercase tracking-tight text-black">
              WHAT HAPPENED?
            </h3>
          </div>
          <p className="font-body text-base text-black/90 leading-relaxed">
            {activeEvent.summary}
          </p>
        </div>

        <div className="border border-black p-6 bg-black text-white">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 bg-white inline-block" />
            <h3 className="font-display text-xl font-black uppercase tracking-tight text-white">
              WHAT DOES IT MEAN?
            </h3>
          </div>
          <p className="font-body text-base text-white/90 leading-relaxed">
            {activeEvent.economicTransmission}
          </p>
        </div>
      </div>
    </section>
  );
}
