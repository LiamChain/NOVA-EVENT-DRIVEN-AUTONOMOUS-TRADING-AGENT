export type OperatingMode = 'SIMULATION' | 'PAPER' | 'LIVE';

export type EventImportance = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';

export type EventStatus = 'ANALYZED' | 'WAITING' | 'UPCOMING' | 'PROCESSING';

export type TradeAction = 'LONG' | 'SHORT' | 'WAIT';

export type DirectionBias = 'BULLISH' | 'BEARISH' | 'NEUTRAL';

export type AgentState = 
  | 'MONITORING'
  | 'ANALYZING'
  | 'REASONING'
  | 'RISK CHECK'
  | 'READY'
  | 'EXECUTING'
  | 'EXECUTED'
  | 'WAITING'
  | 'BLOCKED';

export interface MacroEvent {
  id: string;
  time: string;
  date: string;
  title: string;
  category: 'INFLATION' | 'CENTRAL BANK' | 'LABOR' | 'GROWTH' | 'GEOPOLITICAL' | 'EARNINGS';
  actual: string;
  actualNum: number;
  expected: string;
  expectedNum: number;
  previous: string;
  previousNum: number;
  surprise: string;
  surpriseNum: number;
  unit: string;
  importance: EventImportance;
  status: EventStatus;
  headlineStatement: string; // e.g., "HIGHER THAN EXPECTED"
  macroBias: string; // e.g., "BEARISH RISK ASSETS"
  summary: string;
  economicTransmission: string;
  assetBias: {
    asset: string;
    bias: DirectionBias;
    impact: 'HIGH' | 'MEDIUM' | 'LOW';
    confidence: number;
    rationale: string;
  }[];
}

export interface MacroChainStep {
  label: string;
  value: string;
  subtext?: string;
}

export interface RiskMetrics {
  accountEquity: number;
  maxPortfolioRiskPercent: number;
  proposedRiskPercent: number;
  positionSizeUsd: number;
  entryPrice: number;
  stopPrice: number;
  targetPrice: number;
  stopDistanceUsd: number;
  expectedLossUsd: number;
  expectedGainUsd: number;
  riskRewardRatio: string;
  dailyLossLimitStatus: 'SAFE' | 'WARNING' | 'BREACHED';
}

export interface RiskGateCondition {
  id: string;
  label: string;
  passed: boolean;
  value: string;
  detail: string;
}

export interface DecisionReasoning {
  signalStrength: number;
  eventSurprise: 'HIGH' | 'MODERATE' | 'LOW' | 'NEUTRAL';
  marketAlignment: 'STRONG' | 'MODERATE' | 'WEAK' | 'CONFLICT';
  volatility: 'LOW' | 'NORMAL' | 'ELEVATED' | 'EXTREME';
  liquidity: 'ADEQUATE' | 'MODERATE' | 'INSUFFICIENT';
  conflictingSignals: 'NONE' | 'MINOR' | 'CRITICAL';
  rationale: string;
  waitReason?: string;
}

export interface Decision {
  id: string;
  eventId: string;
  eventTitle: string;
  timestamp: string;
  asset: string;
  action: TradeAction;
  confidence: number;
  timeHorizon: 'IMMEDIATE' | 'SHORT TERM' | 'MEDIUM TERM' | 'POSITION';
  entry: number;
  stop: number;
  target: number;
  riskPercent: number;
  positionSize: number;
  riskReward: string;
  reasoning: DecisionReasoning;
  macroChain: MacroChainStep[];
  status: 'OPEN' | 'CLOSED' | 'EXECUTED' | 'WAITING' | 'REJECTED' | 'BLOCKED';
  pnl?: string;
  auditTrail: {
    eventStep: string;
    marketStep: string;
    riskStep: string;
    finalDecision: string;
  };
}

export interface Trade {
  id: string;
  decisionId: string;
  eventTitle: string;
  asset: string;
  side: 'LONG' | 'SHORT';
  entry: number;
  quantity: number;
  currentPrice: number;
  stop: number;
  target: number;
  mode: OperatingMode;
  status: 'OPEN' | 'FILLED' | 'CLOSED' | 'CANCELLED';
  pnlUsd: number;
  pnlPercent: number;
  timestamp: string;
}

export interface LiveTapeItem {
  id: string;
  timestamp: string;
  source: 'NOVA' | 'RISK ENGINE' | 'ORDER ENGINE' | 'MACRO DETECTOR';
  event: string;
  mode: OperatingMode;
  status: string;
  detail: string;
}

export interface AgentTraceStep {
  id: string;
  timestamp: string;
  phase: string;
  detail: string;
  status?: 'INFO' | 'PASSED' | 'ALERT' | 'FINAL';
}

export interface PortfolioState {
  equity: number;
  availableCapital: number;
  dailyPnL: number;
  openRisk: number;
  riskLimit: number;
  riskUtilization: number;
  positions: Trade[];
  allocations: {
    asset: string;
    weight: number; // percentage e.g. 45
    riskUsd: number;
  }[];
}

export interface MarketAsset {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volatility: 'LOW' | 'NORMAL' | 'ELEVATED' | 'EXTREME';
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  volume24h: string;
}

export interface SettingsState {
  confidenceThreshold: number;
  maxTradeRiskPercent: number;
  dailyLossLimitPercent: number;
  defaultMode: OperatingMode;
  allowLiveExecution: boolean;
  minRiskRewardRatio: number;
}

export interface ReplayStep {
  timestamp: string;
  phase: string;
  title: string;
  headline: string;
  description: string;
  chainLabel: string;
  tapeEntry?: string;
}
