'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowDown, ArrowRight } from 'lucide-react';

export function MacroReasoningChain() {
  const { activeDecision } = useTerminal();
  const chain = activeDecision.macroChain;

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      {/* Title Bar */}
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            MACRO REASONING CHAIN
          </h2>
        </div>
        <span className="font-mono text-xs text-muted-foreground uppercase tracking-widest hidden sm:inline">
          DETERMINISTIC CAUSAL TRANSMISSION
        </span>
      </div>

      {/* Horizontal Flow for Desktop / Vertical for Mobile */}
      <div className="hidden lg:grid grid-cols-6 gap-0 border border-black divide-x divide-black">
        {chain.map((step, idx) => {
          const isLast = idx === chain.length - 1;
          return (
            <div
              key={step.label}
              className={`p-5 flex flex-col justify-between relative ${
                isLast ? 'bg-black text-white' : 'bg-white text-black'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span
                    className={`font-mono text-[10px] uppercase tracking-widest font-bold ${
                      isLast ? 'text-white/70' : 'text-muted-foreground'
                    }`}
                  >
                    STEP 0{idx + 1} // {step.label}
                  </span>
                  {!isLast && <ArrowRight className="w-3.5 h-3.5 text-black" />}
                </div>

                <div
                  className={`font-display text-lg xl:text-xl font-bold uppercase tracking-tight leading-tight mt-2 ${
                    isLast ? 'text-white' : 'text-black'
                  }`}
                >
                  {step.value}
                </div>
              </div>

              {step.subtext && (
                <div
                  className={`font-mono text-[11px] uppercase tracking-wider mt-4 pt-3 border-t ${
                    isLast ? 'border-white/20 text-white/80' : 'border-black/10 text-muted-foreground'
                  }`}
                >
                  {step.subtext}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Mobile Stacked Vertical Flow */}
      <div className="lg:hidden flex flex-col gap-0 border border-black divide-y divide-black">
        {chain.map((step, idx) => {
          const isLast = idx === chain.length - 1;
          return (
            <div
              key={step.label}
              className={`p-4 ${isLast ? 'bg-black text-white' : 'bg-white text-black'}`}
            >
              <div className="flex items-center justify-between">
                <span
                  className={`font-mono text-[10px] uppercase tracking-widest font-bold ${
                    isLast ? 'text-white/70' : 'text-muted-foreground'
                  }`}
                >
                  0{idx + 1} — {step.label}
                </span>
                {!isLast && <ArrowDown className="w-3.5 h-3.5 text-black" />}
              </div>

              <div
                className={`font-display text-lg font-bold uppercase tracking-tight mt-1 ${
                  isLast ? 'text-white' : 'text-black'
                }`}
              >
                {step.value}
              </div>

              {step.subtext && (
                <div
                  className={`font-mono text-[10px] uppercase tracking-wider mt-1 ${
                    isLast ? 'text-white/70' : 'text-muted-foreground'
                  }`}
                >
                  {step.subtext}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
