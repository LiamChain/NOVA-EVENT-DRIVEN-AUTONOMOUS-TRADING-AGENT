'use client';

import React from 'react';
import Link from 'next/link';
import { notFound, useParams } from 'next/navigation';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowLeft, ArrowRight, ArrowUpRight, ArrowDownRight, Minus, ShieldCheck, Cpu } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function EventDetailPage() {
  const params = useParams();
  const id = params?.id as string;
  const { events, selectEvent, decisions } = useTerminal();

  const event = events.find((e) => e.id === id);

  if (!event) {
    return (
      <div className="border-4 border-black p-12 text-center my-12 bg-white">
        <h1 className="font-display text-4xl font-black uppercase tracking-tight text-black mb-4">
          EVENT NOT FOUND
        </h1>
        <p className="font-body text-base text-muted-foreground mb-6">
          The requested macro event does not exist in the indexed database.
        </p>
        <Link
          href="/events"
          className="inline-flex items-center gap-2 px-6 py-3 bg-black text-white font-mono text-xs font-bold uppercase tracking-widest"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO EVENTS DIRECTORY</span>
        </Link>
      </div>
    );
  }

  const isSurprisePositive = event.surpriseNum > 0;
  const isSurpriseNegative = event.surpriseNum < 0;

  // Find associated decision if available
  const relatedDecision = decisions.find((d) => d.eventId === event.id);

  return (
    <div className="space-y-8 pb-12">
      {/* Back Link */}
      <div>
        <Link
          href="/events"
          className="inline-flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-widest text-black hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO ALL EVENTS</span>
        </Link>
      </div>

      {/* Main Header */}
      <div className="border-b-4 border-black pb-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">
              <span className="w-2 h-2 bg-black inline-block" />
              <span>CATEGORY: {event.category}</span>
              <span>|</span>
              <span>DATE: {event.date} {event.time} UTC</span>
            </div>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              {event.title}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/terminal"
              onClick={() => selectEvent(event.id)}
              className="flex items-center gap-2 px-6 py-4 bg-black text-white border-2 border-black font-mono text-xs font-black tracking-widest uppercase hover:bg-white hover:text-black transition-colors"
            >
              <span>ANALYZE IN TERMINAL</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>

      {/* Hero Metric Matrix */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-0 border-2 border-black divide-x divide-y lg:divide-y-0 divide-black bg-white">
        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            ACTUAL
          </span>
          <div className="font-mono text-4xl sm:text-5xl font-black text-black">
            {event.actual}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            REPORTED NUMBER
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            EXPECTED
          </span>
          <div className="font-mono text-4xl sm:text-5xl font-bold text-muted-foreground">
            {event.expected}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            MARKET CONSENSUS
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            PREVIOUS
          </span>
          <div className="font-mono text-4xl sm:text-5xl font-bold text-muted-foreground">
            {event.previous}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            PRIOR PERIOD PRINT
          </span>
        </div>

        <div className="p-6 bg-black text-white">
          <span className="font-mono text-xs uppercase tracking-widest text-white/70 block mb-2">
            CALCULATED SURPRISE
          </span>
          <div className="font-mono text-4xl sm:text-5xl font-black flex items-center gap-2">
            {event.surprise}
            {isSurprisePositive && <ArrowUpRight className="w-8 h-8 text-white" />}
            {isSurpriseNegative && <ArrowDownRight className="w-8 h-8 text-white" />}
            {!isSurprisePositive && !isSurpriseNegative && <Minus className="w-8 h-8 text-white" />}
          </div>
          <span className="font-mono text-[10px] uppercase tracking-widest text-white/70 mt-1 block">
            STATISTICAL SPREAD
          </span>
        </div>
      </div>

      {/* Editorial Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="border-2 border-black p-6 bg-white">
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black mb-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-black inline-block" />
            <span>EXECUTIVE SUMMARY & EVENT SIGNIFICANCE</span>
          </h2>
          <p className="font-body text-base text-black/90 leading-relaxed">
            {event.summary}
          </p>
        </div>

        <div className="border-2 border-black p-6 bg-black text-white">
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-white mb-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-white inline-block" />
            <span>ECONOMIC TRANSMISSION MECHANISM</span>
          </h2>
          <p className="font-body text-base text-white/90 leading-relaxed">
            {event.economicTransmission}
          </p>
        </div>
      </div>

      {/* Section Divider */}
      <SectionRule
        thickness={4}
        title="CROSS-ASSET PROPAGATION MATRIX"
        meta="INTERMARKET VECTORS"
      />

      {/* Cross-Asset Impact Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {event.assetBias.map((asset) => (
          <div key={asset.asset} className="border-2 border-black p-5 bg-white flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-black/10 pb-3">
                <span className="font-mono text-sm font-bold text-black">{asset.asset}</span>
                <span className="font-mono text-xs font-bold uppercase px-2 py-0.5 border border-black bg-black text-white">
                  {asset.bias}
                </span>
              </div>
              <p className="font-body text-xs text-black/80 mt-3 leading-relaxed">
                {asset.rationale}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-black/10 flex justify-between font-mono text-xs">
              <span className="text-muted-foreground uppercase text-[10px]">IMPACT: {asset.impact}</span>
              <span className="font-bold text-black">CONVICTION: {asset.confidence}%</span>
            </div>
          </div>
        ))}
      </div>

      {/* Associated Decision if any */}
      {relatedDecision && (
        <>
          <SectionRule
            thickness={4}
            title="NOVA DECISION AUDIT RECORD"
            meta="HISTORICAL VERIFICATION"
          />

          <div className="border-2 border-black p-6 bg-muted/20 font-mono text-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-black pb-4 mb-4">
              <div>
                <span className="text-[10px] text-muted-foreground uppercase block">DECISION RECORD ID</span>
                <span className="font-bold text-base text-black">{relatedDecision.id}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-bold text-sm bg-black text-white px-3 py-1 uppercase">
                  {relatedDecision.action} {relatedDecision.asset}
                </span>
                <span className="font-bold">CONFIDENCE {relatedDecision.confidence}%</span>
              </div>
            </div>

            <p className="font-body text-sm text-black/80 mb-4">
              {relatedDecision.reasoning.rationale}
            </p>

            <Link
              href={`/decisions/${relatedDecision.id}`}
              className="inline-flex items-center gap-2 font-bold uppercase underline hover:text-muted-foreground"
            >
              <span>INSPECT FULL DECISION AUDIT CHAIN →</span>
            </Link>
          </div>
        </>
      )}
    </div>
  );
}
