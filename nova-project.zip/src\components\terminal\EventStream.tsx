'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export function EventStream() {
  const { events, activeEvent, selectEvent } = useTerminal();

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            EVENT STREAM
          </h2>
        </div>
        <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest hidden sm:block">
          GLOBAL MACRO FEED // SELECT ROW TO ANALYZE
        </div>
      </div>

      {/* Table Format */}
      <div className="overflow-x-auto">
        <table className="w-full text-left font-mono text-xs border-collapse">
          <thead>
            <tr className="border-b-2 border-black text-muted-foreground uppercase text-[10px] tracking-widest">
              <th className="py-3 px-3">TIME</th>
              <th className="py-3 px-3">EVENT</th>
              <th className="py-3 px-3 text-right">ACTUAL</th>
              <th className="py-3 px-3 text-right">EXPECTED</th>
              <th className="py-3 px-3 text-right">SURPRISE</th>
              <th className="py-3 px-3 text-center">IMPACT</th>
              <th className="py-3 px-3 text-right">STATUS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/10">
            {events.map((evt) => {
              const isSelected = evt.id === activeEvent.id;
              const isSurprisePositive = evt.surpriseNum > 0;
              const isSurpriseNegative = evt.surpriseNum < 0;

              return (
                <tr
                  key={evt.id}
                  onClick={() => selectEvent(evt.id)}
                  className={`cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-black text-white font-bold'
                      : 'hover:bg-muted/40 text-black'
                  }`}
                >
                  <td className="py-4 px-3 whitespace-nowrap">
                    {evt.time}
                  </td>
                  <td className="py-4 px-3 font-semibold">
                    <div className="flex items-center gap-2">
                      {isSelected && <span className="w-1.5 h-1.5 bg-white inline-block" />}
                      <span>{evt.title}</span>
                    </div>
                  </td>
                  <td className="py-4 px-3 text-right whitespace-nowrap">
                    {evt.actual}
                  </td>
                  <td className={`py-4 px-3 text-right whitespace-nowrap ${isSelected ? 'text-white/70' : 'text-muted-foreground'}`}>
                    {evt.expected}
                  </td>
                  <td className="py-4 px-3 text-right whitespace-nowrap font-bold">
                    <span className="inline-flex items-center gap-1 justify-end">
                      {evt.surprise}
                      {isSurprisePositive && <ArrowUpRight className="w-3 h-3" />}
                      {isSurpriseNegative && <ArrowDownRight className="w-3 h-3" />}
                      {!isSurprisePositive && !isSurpriseNegative && <Minus className="w-3 h-3" />}
                    </span>
                  </td>
                  <td className="py-4 px-3 text-center whitespace-nowrap">
                    <span
                      className={`inline-block px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider border ${
                        isSelected
                          ? 'border-white text-white'
                          : evt.importance === 'CRITICAL'
                          ? 'border-black bg-black text-white'
                          : 'border-black text-black'
                      }`}
                    >
                      {evt.importance}
                    </span>
                  </td>
                  <td className="py-4 px-3 text-right whitespace-nowrap">
                    <span className="text-[10px] tracking-wider uppercase font-bold">
                      {evt.status}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
