'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { INITIAL_MARKET_ASSETS } from '@/lib/data';
import { Activity, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export function MarketContext() {
  const { activeDecision, activeEvent } = useTerminal();

  // Alignment derivation
  const isShort = activeDecision.action === 'SHORT';
  const isLong = activeDecision.action === 'LONG';
  const isWait = activeDecision.action === 'WAIT';

  const eventSignal = isShort ? 'BEARISH' : isLong ? 'BULLISH' : 'NEUTRAL';
  const marketTrend = isShort ? 'BEARISH' : isLong ? 'BULLISH' : 'NEUTRAL';
  const momentum = isShort ? 'BEARISH' : isLong ? 'BULLISH' : 'MIXED';
  const volatility = 'ELEVATED';
  const alignment = isWait ? 'CONFLICT / WEAK' : 'STRONG';

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            MARKET CONTEXT & ALIGNMENT
          </h2>
        </div>
        <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest hidden sm:flex items-center gap-2">
          <Activity className="w-4 h-4 text-black" />
          <span>CROSS-MARKET TELEMETRY</span>
        </div>
      </div>

      {/* Contextual Intelligence Comparator */}
      <div className="border-2 border-black p-5 bg-muted/20 mb-6">
        <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-2 font-bold">
          CONTEXTUAL INTELLIGENCE ENGINE // SIGNAL HARMONIZATION
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono text-xs">
          <div className="border border-black p-3 bg-white">
            <span className="text-muted-foreground text-[10px] uppercase block">EVENT SIGNAL</span>
            <span className="font-bold text-sm text-black">{eventSignal}</span>
          </div>

          <div className="border border-black p-3 bg-white">
            <span className="text-muted-foreground text-[10px] uppercase block">MARKET TREND</span>
            <span className="font-bold text-sm text-black">{marketTrend}</span>
          </div>

          <div className="border border-black p-3 bg-white">
            <span className="text-muted-foreground text-[10px] uppercase block">MOMENTUM</span>
            <span className="font-bold text-sm text-black">{momentum}</span>
          </div>

          <div className="border border-black p-3 bg-white">
            <span className="text-muted-foreground text-[10px] uppercase block">VOLATILITY</span>
            <span className="font-bold text-sm text-black">{volatility}</span>
          </div>

          <div className="border-2 border-black p-3 bg-black text-white col-span-2 sm:col-span-1">
            <span className="text-white/70 text-[10px] uppercase block">ALIGNMENT</span>
            <span className="font-bold text-sm text-white">{alignment}</span>
          </div>
        </div>
      </div>

      {/* Ticker Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-0 border border-black divide-y sm:divide-y-0 sm:divide-x divide-black">
        {INITIAL_MARKET_ASSETS.slice(0, 6).map((asset) => {
          const isUp = asset.change24h > 0;
          return (
            <div key={asset.symbol} className="p-3 bg-white">
              <div className="flex items-center justify-between text-[10px] font-mono text-muted-foreground uppercase">
                <span>{asset.symbol}</span>
                <span>{asset.trend}</span>
              </div>
              <div className="font-mono text-base font-bold text-black mt-1">
                {typeof asset.price === 'number' && asset.price > 500
                  ? `$${asset.price.toLocaleString()}`
                  : asset.price}
              </div>
              <div className="flex items-center gap-1 font-mono text-[11px] font-bold mt-0.5">
                <span>
                  {asset.change24h >= 0 ? '+' : ''}
                  {asset.change24h}%
                </span>
                {isUp ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
