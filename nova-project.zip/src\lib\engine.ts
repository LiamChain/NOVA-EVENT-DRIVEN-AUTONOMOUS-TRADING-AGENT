import { MacroEvent, Decision, RiskMetrics, RiskGateCondition, SettingsState, TradeAction, DirectionBias } from '../types';

export function evaluateEventReasoning(
  event: MacroEvent,
  settings: SettingsState,
  currentOpenRiskPercent: number = 0.6
): {
  decision: Decision;
  riskMetrics: RiskMetrics;
  riskGates: RiskGateCondition[];
  executionReady: boolean;
  blockReason?: string;
} {
  const surpriseVal = event.actualNum - event.expectedNum;
  const absSurprise = Math.abs(surpriseVal);
  const isZeroSurprise = absSurprise < 0.001;

  let baseAction: TradeAction = 'WAIT';
  let targetAsset = 'BTC/USDT';
  let currentPrice = 64280;
  let rationale = '';
  let headline = '';
  let macroProj = '';
  let policyProj = '';
  let marketProj = '';
  let rawConfidence = 50;

  if (event.category === 'INFLATION') {
    if (surpriseVal > 0.05) {
      baseAction = 'SHORT';
      targetAsset = 'BTC/USDT';
      rawConfidence = Math.min(94, Math.round(75 + absSurprise * 40));
      rationale = `Inflation printed +${surpriseVal.toFixed(1)}${event.unit} above expectations, validating higher-for-longer regime and expanding real interest yields. Risk-sensitive assets face discount rate contraction.`;
      headline = 'INFLATION ACCELERATION';
      macroProj = 'HIGHER FOR LONGER';
      policyProj = 'RESTRICTIVE BIAS';
      marketProj = 'REAL YIELDS ↑ / CRYPTO ↓';
    } else if (surpriseVal < -0.05) {
      baseAction = 'LONG';
      targetAsset = 'BTC/USDT';
      rawConfidence = Math.min(94, Math.round(76 + absSurprise * 35));
      rationale = `Inflation printed ${surpriseVal.toFixed(1)}${event.unit} below expectations, confirming disinflationary trajectory and granting the central bank room for monetary accommodation.`;
      headline = 'DISINFLATION CONFIRMED';
      macroProj = 'EASING PATH OPEN';
      policyProj = 'ACCOMMODATIVE DRIFT';
      marketProj = 'REAL YIELDS ↓ / RISK-ON';
    } else {
      baseAction = 'WAIT';
      rawConfidence = 58;
      rationale = `Inflation met consensus within margin of error (${surpriseVal >= 0 ? '+' : ''}${surpriseVal.toFixed(2)}${event.unit}). Directional impulse absent; capital conservation prioritised.`;
      headline = 'IN-LINE INFLATION';
      macroProj = 'STATUS QUO';
      policyProj = 'NEUTRAL HOLD';
      marketProj = 'VOLATILITY CONTRACTION';
    }
  } else if (event.category === 'LABOR') {
    if (surpriseVal > 25) {
      baseAction = 'SHORT';
      targetAsset = 'NASDAQ 100';
      currentPrice = 18320;
      rawConfidence = Math.min(92, Math.round(72 + (absSurprise / 100) * 15));
      rationale = `Labor market expansion exceeded estimates by +${surpriseVal}${event.unit}, sustaining wage persistence and suppressing the case for near-term precautionary easing.`;
      headline = 'LABOR MARKET RESILIENCE';
      macroProj = 'WAGE PERSISTENCE';
      policyProj = 'HAWKISH PAUSE';
      marketProj = 'VALUATION SQUEEZE';
    } else if (surpriseVal < -25) {
      baseAction = 'SHORT';
      targetAsset = 'BTC/USDT';
      rawConfidence = 66;
      rationale = `Severe labor deceleration raises contractionary recession risk. Conflicting drivers between rate cuts and growth destruction mandate caution.`;
      headline = 'GROWTH CONTRACTION RISK';
      macroProj = 'SLOWDOWN AHEAD';
      policyProj = 'EMERGENCY EASING';
      marketProj = 'RECESSIONARY UNCERTAINTY';
    } else {
      baseAction = 'WAIT';
      rawConfidence = 55;
      rationale = `Labor data within expected volatility bands. Directional edge absent.`;
      headline = 'LABOR CONSENSUS';
      macroProj = 'STABLE EMPLOYMENT';
      policyProj = 'DATA DEPENDENT';
      marketProj = 'RANGE-BOUND';
    }
  } else if (event.category === 'CENTRAL BANK') {
    if (isZeroSurprise) {
      baseAction = 'WAIT';
      rawConfidence = 61;
      rationale = `Rate decision adhered strictly to pre-priced consensus. Forward dot-plot distributions suggest balanced two-sided risk without clear macro edge.`;
      headline = 'CONSENSUS RATE DECISION';
      macroProj = 'PAUSE MAINTAINED';
      policyProj = 'DATA-DEPENDENT GUIDANCE';
      marketProj = 'TWO-WAY ORDER FLOW';
    } else if (surpriseVal > 0) {
      baseAction = 'SHORT';
      rawConfidence = 89;
      rationale = `Unexpected policy hike tightening financial conditions. Liquidity extraction will pressure speculative valuations.`;
      headline = 'SURPRISE RATE HIKE';
      macroProj = 'AGGRESSIVE TIGHTENING';
      policyProj = 'HAWKISH REGIME';
      marketProj = 'BROAD DELEVERAGING';
    } else {
      baseAction = 'LONG';
      rawConfidence = 91;
      rationale = `Surprise rate reduction easing liquidity conditions across the banking system. Positive for hard assets and risk proxies.`;
      headline = 'SURPRISE RATE CUT';
      macroProj = 'LIQUIDITY INJECTION';
      policyProj = 'DOVISH ACCELERATION';
      marketProj = 'SPECULATIVE EXPANSION';
    }
  } else {
    // Default / Growth / Geopolitical / Custom
    if (surpriseVal > 0) {
      baseAction = 'LONG';
      rawConfidence = Math.min(88, Math.round(70 + absSurprise * 10));
      rationale = `Data beat expectations by ${surpriseVal.toFixed(1)}${event.unit}, supporting macroeconomic expansion and corporate cash flow strength.`;
      headline = 'POSITIVE MACRO SURPRISE';
      macroProj = 'ECONOMIC EXPANSION';
      policyProj = 'BENIGN REGIME';
      marketProj = 'CAPITAL ROTATION';
    } else if (surpriseVal < 0) {
      baseAction = 'SHORT';
      rawConfidence = Math.min(86, Math.round(68 + absSurprise * 10));
      rationale = `Data trailed consensus by ${Math.abs(surpriseVal).toFixed(1)}${event.unit}, dampening aggregate growth projections.`;
      headline = 'MACRO UNDERPERFORMANCE';
      macroProj = 'ECONOMIC DECELERATION';
      policyProj = 'DEFENSIVE CONDITIONS';
      marketProj = 'FLIGHT TO CASH';
    } else {
      baseAction = 'WAIT';
      rawConfidence = 52;
      rationale = `Print matched consensus. No tradeable edge identified.`;
      headline = 'IN-LINE METRICS';
      macroProj = 'EQUILIBRIUM';
      policyProj = 'NO CHANGE';
      marketProj = 'NEUTRAL DRIFT';
    }
  }

  // Check confidence threshold from settings
  let finalAction: TradeAction = baseAction;
  let waitReason: string | undefined = undefined;

  if (rawConfidence < settings.confidenceThreshold && baseAction !== 'WAIT') {
    finalAction = 'WAIT';
    waitReason = `Confidence score (${rawConfidence}%) sits below institutional safety threshold of ${settings.confidenceThreshold}%. Capital preservation triggered.`;
  } else if (baseAction === 'WAIT') {
    waitReason = 'Event surprise magnitude does not provide a statistically robust directional edge.';
  }

  // Price calculations
  let entryPrice = currentPrice;
  let stopPrice = 0;
  let targetPrice = 0;
  let positionSizeUsd = 0;
  let proposedRiskPercent = 0;
  let expectedLossUsd = 0;
  let expectedGainUsd = 0;
  let stopDistanceUsd = 0;
  let rrRatio = 'N/A';

  const accountEquity = 25000;

  if (finalAction === 'SHORT') {
    stopPrice = Math.round(entryPrice * 1.022); // ~2.2% stop
    targetPrice = Math.round(entryPrice * 0.947); // ~5.3% target
    stopDistanceUsd = stopPrice - entryPrice;
    proposedRiskPercent = Math.min(0.6, settings.maxTradeRiskPercent);
    expectedLossUsd = Math.round((accountEquity * proposedRiskPercent) / 100);
    positionSizeUsd = Math.round((expectedLossUsd / (stopDistanceUsd / entryPrice)));
    expectedGainUsd = Math.round(positionSizeUsd * ((entryPrice - targetPrice) / entryPrice));
    rrRatio = `1 : ${( (entryPrice - targetPrice) / stopDistanceUsd ).toFixed(1)}`;
  } else if (finalAction === 'LONG') {
    stopPrice = Math.round(entryPrice * 0.98); // ~2.0% stop
    targetPrice = Math.round(entryPrice * 1.05); // ~5.0% target
    stopDistanceUsd = entryPrice - stopPrice;
    proposedRiskPercent = Math.min(0.6, settings.maxTradeRiskPercent);
    expectedLossUsd = Math.round((accountEquity * proposedRiskPercent) / 100);
    positionSizeUsd = Math.round((expectedLossUsd / (stopDistanceUsd / entryPrice)));
    expectedGainUsd = Math.round(positionSizeUsd * ((targetPrice - entryPrice) / entryPrice));
    rrRatio = `1 : ${( (targetPrice - entryPrice) / stopDistanceUsd ).toFixed(1)}`;
  }

  const riskMetrics: RiskMetrics = {
    accountEquity,
    maxPortfolioRiskPercent: settings.maxTradeRiskPercent,
    proposedRiskPercent: finalAction === 'WAIT' ? 0 : proposedRiskPercent,
    positionSizeUsd: finalAction === 'WAIT' ? 0 : positionSizeUsd,
    entryPrice: finalAction === 'WAIT' ? 0 : entryPrice,
    stopPrice,
    targetPrice,
    stopDistanceUsd,
    expectedLossUsd: finalAction === 'WAIT' ? 0 : expectedLossUsd,
    expectedGainUsd: finalAction === 'WAIT' ? 0 : expectedGainUsd,
    riskRewardRatio: rrRatio,
    dailyLossLimitStatus: currentOpenRiskPercent >= settings.dailyLossLimitPercent ? 'BREACHED' : 'SAFE',
  };

  // 5-Point Independent Risk Gate Evaluation
  const signalPassed = finalAction !== 'WAIT' && rawConfidence >= settings.confidenceThreshold;
  const marketPassed = !isZeroSurprise;
  const liquidityPassed = true; // High-depth order books on major pairs
  const riskPassed = proposedRiskPercent <= settings.maxTradeRiskPercent;
  const exposurePassed = (currentOpenRiskPercent + proposedRiskPercent) <= settings.dailyLossLimitPercent;

  const riskGates: RiskGateCondition[] = [
    {
      id: 'gate-signal',
      label: 'SIGNAL VALIDATION',
      passed: signalPassed,
      value: finalAction === 'WAIT' ? 'WAIT (NO EDGE)' : `${finalAction} (${rawConfidence}%)`,
      detail: signalPassed ? 'Confidence satisfies risk hurdle' : (waitReason || 'Confidence below threshold'),
    },
    {
      id: 'gate-market',
      label: 'MARKET ALIGNMENT',
      passed: marketPassed,
      value: marketPassed ? 'CONFIRMED' : 'NEUTRAL / CONFLICT',
      detail: marketPassed ? 'Cross-asset flows confirm macro impulse' : 'Market structure contradicts or absorbs signal',
    },
    {
      id: 'gate-liquidity',
      label: 'LIQUIDITY DEPTH',
      passed: liquidityPassed,
      value: 'ADEQUATE',
      detail: 'Estimated slippage < 2.5 basis points for proposed sizing',
    },
    {
      id: 'gate-risk',
      label: 'PORTFOLIO RISK HURDLE',
      passed: riskPassed,
      value: `${proposedRiskPercent.toFixed(1)}% / ${settings.maxTradeRiskPercent.toFixed(1)}%`,
      detail: riskPassed ? 'Proposed risk within allowable bounds' : 'Proposed risk exceeds individual trade cap',
    },
    {
      id: 'gate-exposure',
      label: 'AGGREGATE EXPOSURE',
      passed: exposurePassed,
      value: `${(currentOpenRiskPercent + proposedRiskPercent).toFixed(1)}% / ${settings.dailyLossLimitPercent.toFixed(1)}%`,
      detail: exposurePassed ? 'Portfolio risk utilization safe' : 'Portfolio exposure breaches daily risk ceiling',
    },
  ];

  const executionReady = riskGates.every(g => g.passed);
  let blockReason: string | undefined = undefined;

  if (!executionReady) {
    const failedGate = riskGates.find(g => !g.passed);
    blockReason = failedGate ? `${failedGate.label}: ${failedGate.detail}` : 'Risk conditions unmet';
  }

  // Macro Reasoning Chain
  const macroChain = [
    { label: 'EVENT', value: `${event.title} (${event.surprise})`, subtext: `ACTUAL ${event.actual} VS ${event.expected} EXP` },
    { label: 'SURPRISE', value: headline, subtext: `${Math.abs(surpriseVal).toFixed(2)}${event.unit} SPREAD FROM CONSENSUS` },
    { label: 'MACRO', value: macroProj, subtext: 'TRANSMISSION REGIME' },
    { label: 'POLICY', value: policyProj, subtext: 'CENTRAL BANK REACTION FUNCTION' },
    { label: 'CROSS-ASSET', value: marketProj, subtext: 'CROSS-MARKET DISCOUNTING' },
    { label: 'DECISION', value: finalAction === 'WAIT' ? 'CAPITAL DEFENSE: WAIT' : `${targetAsset} ${finalAction}`, subtext: finalAction === 'WAIT' ? 'NO UNCOMPENSATED RISK' : `CONFIDENCE ${rawConfidence}%` },
  ];

  const decision: Decision = {
    id: `dec-${event.id}-${Date.now().toString().slice(-4)}`,
    eventId: event.id,
    eventTitle: event.title,
    timestamp: `${event.date} ${event.time}`,
    asset: targetAsset,
    action: finalAction,
    confidence: rawConfidence,
    timeHorizon: 'SHORT TERM',
    entry: entryPrice,
    stop: stopPrice,
    target: targetPrice,
    riskPercent: proposedRiskPercent,
    positionSize: positionSizeUsd,
    riskReward: rrRatio,
    reasoning: {
      signalStrength: rawConfidence,
      eventSurprise: absSurprise > 0.15 ? 'HIGH' : absSurprise > 0.05 ? 'MODERATE' : 'LOW',
      marketAlignment: marketPassed ? 'STRONG' : 'CONFLICT',
      volatility: 'NORMAL',
      liquidity: 'ADEQUATE',
      conflictingSignals: finalAction === 'WAIT' ? 'CRITICAL' : 'NONE',
      rationale,
      waitReason,
    },
    macroChain,
    status: finalAction === 'WAIT' ? 'WAITING' : 'OPEN',
    pnl: finalAction === 'WAIT' ? '0.00%' : '+0.00%',
    auditTrail: {
      eventStep: `${event.title} released at ${event.actual} vs ${event.expected} expected (${event.surprise} surprise).`,
      marketStep: `Market context evaluated across DXY, Yields, and Liquidity proxies. Trend alignment evaluated as ${marketPassed ? 'STRONG' : 'NEUTRAL'}.`,
      riskStep: `Risk Gate passed: ${riskGates.filter(g => g.passed).length}/5 gates satisfied. Risk cap evaluated against equity.`,
      finalDecision: finalAction === 'WAIT' 
        ? `WAIT directive issued. Reason: ${waitReason}`
        : `${finalAction} on ${targetAsset} approved for execution at $${entryPrice.toLocaleString()}.`,
    },
  };

  return {
    decision,
    riskMetrics,
    riskGates,
    executionReady,
    blockReason,
  };
}
