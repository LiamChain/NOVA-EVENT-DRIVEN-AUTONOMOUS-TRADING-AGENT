'use client';

import React, { useState, useEffect, useRef } from 'react';
import { HISTORICAL_REPLAY_STEPS } from '@/lib/data';
import { Play, Pause, RotateCcw, SkipForward, ArrowRight, ShieldCheck, Check } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function ReplayPage() {
  const [selectedEventId, setSelectedEventId] = useState<'cpi-2026-09' | 'ppi-2026-08'>('cpi-2026-09');
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState<1 | 2 | 4>(1);

  const steps = HISTORICAL_REPLAY_STEPS[selectedEventId] || HISTORICAL_REPLAY_STEPS['cpi-2026-09'];
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isPlaying) {
      const intervalMs = Math.round(2000 / speed);
      timerRef.current = setInterval(() => {
        setCurrentStepIndex((prev) => {
          if (prev >= steps.length - 1) {
            setIsPlaying(false);
            return prev;
          }
          return prev + 1;
        });
      }, intervalMs);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, speed, steps.length]);

  const handleReset = () => {
    setIsPlaying(false);
    setCurrentStepIndex(0);
  };

  const handleStep = () => {
    setIsPlaying(false);
    setCurrentStepIndex((prev) => Math.min(steps.length - 1, prev + 1));
  };

  const currentStep = steps[currentStepIndex];

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              FORENSIC INVESTIGATION SUITE
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              REPLAY THE EVENT
            </h1>
            <p className="font-display text-xl sm:text-2xl font-bold uppercase tracking-tight text-black mt-2">
              RUN NOVA AS IF HISTORY JUST HAPPENED.
            </p>
          </div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
            <span>DETERMINISTIC MILLISECOND AUDIT TRACE</span>
          </div>
        </div>
      </div>

      {/* Replay Config & Controls Bar */}
      <div className="border-2 border-black bg-white p-6 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        {/* Event Selector */}
        <div className="flex items-center gap-3 font-mono text-xs">
          <span className="font-bold uppercase text-muted-foreground">SELECT CATALYST:</span>
          <button
            onClick={() => {
              setSelectedEventId('cpi-2026-09');
              handleReset();
            }}
            className={`px-3 py-1.5 uppercase font-bold border ${
              selectedEventId === 'cpi-2026-09'
                ? 'bg-black text-white border-black'
                : 'bg-white text-black border-border-light hover:border-black'
            }`}
          >
            US CPI (+20 BPS SHOCK)
          </button>
          <button
            onClick={() => {
              setSelectedEventId('ppi-2026-08');
              handleReset();
            }}
            className={`px-3 py-1.5 uppercase font-bold border ${
              selectedEventId === 'ppi-2026-08'
                ? 'bg-black text-white border-black'
                : 'bg-white text-black border-border-light hover:border-black'
            }`}
          >
            US PPI (-50 BPS DOVISH)
          </button>
        </div>

        {/* Player Controls */}
        <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="flex items-center gap-2 px-5 py-2.5 bg-black text-white border border-black font-bold uppercase hover:bg-white hover:text-black transition-colors"
          >
            {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isPlaying ? 'PAUSE' : 'PLAY'}</span>
          </button>

          <button
            onClick={handleStep}
            disabled={currentStepIndex >= steps.length - 1}
            className="flex items-center gap-1.5 px-4 py-2.5 border border-black hover:bg-muted font-bold uppercase transition-colors disabled:opacity-40"
          >
            <SkipForward className="w-3.5 h-3.5" />
            <span>STEP</span>
          </button>

          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 px-4 py-2.5 border border-black hover:bg-muted font-bold uppercase transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          {/* Speed Selector */}
          <div className="flex items-center border border-black ml-2 p-0.5">
            {([1, 2, 4] as const).map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                className={`px-2.5 py-1 uppercase font-bold text-[10px] ${
                  speed === s ? 'bg-black text-white' : 'text-black hover:bg-muted'
                }`}
              >
                {s}×
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active Forensic Stage Hero */}
      <div className="border-4 border-black bg-white p-6 md:p-10">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b-2 border-black pb-4 mb-6">
          <div className="flex items-center gap-3 font-mono text-xs">
            <span className="w-3 h-3 bg-black inline-block" />
            <span className="font-bold text-black uppercase">
              STAGE 0{currentStepIndex + 1} OF 0{steps.length}
            </span>
            <span className="text-muted-foreground">|</span>
            <span className="font-mono text-muted-foreground">OFFSET: +{currentStep.timestamp}</span>
          </div>

          <span className="font-mono text-xs font-bold uppercase bg-black text-white px-3 py-1">
            {currentStep.phase}
          </span>
        </div>

        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
            {currentStep.title}
          </span>
          <h2 className="font-display text-3xl sm:text-5xl font-black uppercase tracking-tight text-black mb-4">
            {currentStep.headline}
          </h2>
          <p className="font-body text-lg text-black/85 max-w-3xl leading-relaxed">
            {currentStep.description}
          </p>

          {currentStep.tapeEntry && (
            <div className="mt-8 p-4 border border-black bg-muted/40 font-mono text-xs flex items-center gap-3">
              <span className="font-bold text-black uppercase bg-black text-white px-2 py-0.5 text-[10px]">
                TELEMETRY CAPTURE
              </span>
              <span className="text-black font-semibold">{currentStep.tapeEntry}</span>
            </div>
          )}
        </div>
      </div>

      {/* Forensic Timeline Track */}
      <SectionRule
        thickness={4}
        title="FORENSIC TIMELINE SEQUENCE"
        meta="STEP PROGRESSION"
      />

      <div className="space-y-3 font-mono text-xs">
        {steps.map((step, idx) => {
          const isCurrent = idx === currentStepIndex;
          const isPast = idx < currentStepIndex;

          return (
            <div
              key={step.phase}
              onClick={() => {
                setIsPlaying(false);
                setCurrentStepIndex(idx);
              }}
              className={`border p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer transition-colors ${
                isCurrent
                  ? 'border-2 border-black bg-black text-white font-bold'
                  : isPast
                  ? 'border-black bg-muted/20 text-black hover:bg-muted/40'
                  : 'border-border-light bg-white text-muted-foreground opacity-60 hover:opacity-100'
              }`}
            >
              <div className="flex items-center gap-4">
                <span className={`w-5 h-5 flex items-center justify-center border text-[10px] ${
                  isCurrent
                    ? 'border-white text-white font-bold'
                    : isPast
                    ? 'border-black text-black bg-black text-white'
                    : 'border-border-light text-muted-foreground'
                }`}>
                  {isPast ? '✓' : idx + 1}
                </span>

                <div>
                  <span className={`text-[10px] uppercase tracking-wider block ${isCurrent ? 'text-white/70' : 'text-muted-foreground'}`}>
                    +{step.timestamp} // {step.phase}
                  </span>
                  <div className="text-sm font-bold uppercase tracking-tight">
                    {step.title}
                  </div>
                </div>
              </div>

              <div className="text-right">
                <span className={`text-[11px] uppercase tracking-wider px-2 py-0.5 border ${
                  isCurrent
                    ? 'border-white text-white'
                    : 'border-black text-black'
                }`}>
                  {step.chainLabel}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
