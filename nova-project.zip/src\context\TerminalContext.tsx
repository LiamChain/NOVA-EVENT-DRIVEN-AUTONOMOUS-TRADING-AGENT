'use client';

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  MacroEvent,
  Decision,
  Trade,
  LiveTapeItem,
  AgentTraceStep,
  AgentState,
  OperatingMode,
  PortfolioState,
  SettingsState,
  RiskMetrics,
  RiskGateCondition,
} from '../types';
import {
  INITIAL_EVENTS,
  INITIAL_DECISIONS,
  INITIAL_TRADES,
  INITIAL_SETTINGS,
} from '../lib/data';
import { evaluateEventReasoning } from '../lib/engine';

interface TerminalContextType {
  events: MacroEvent[];
  activeEvent: MacroEvent;
  selectEvent: (id: string) => void;
  operatingMode: OperatingMode;
  setOperatingMode: (mode: OperatingMode) => void;
  settings: SettingsState;
  updateSettings: (newSettings: Partial<SettingsState>) => void;
  decisions: Decision[];
  activeDecision: Decision;
  riskMetrics: RiskMetrics;
  riskGates: RiskGateCondition[];
  executionReady: boolean;
  blockReason?: string;
  portfolio: PortfolioState;
  tradeTape: LiveTapeItem[];
  agentTrace: AgentTraceStep[];
  agentStatus: AgentState;
  isSimulating: boolean;
  isConfirmingExecution: boolean;
  setIsConfirmingExecution: (val: boolean) => void;
  isSimModalOpen: boolean;
  setIsSimModalOpen: (val: boolean) => void;
  executeTrade: () => void;
  rejectSignal: () => void;
  closePosition: (tradeId: string) => void;
  triggerSimulation: (customEvent: Partial<MacroEvent>) => Promise<void>;
  resetToDefault: () => void;
}

const TerminalContext = createContext<TerminalContextType | undefined>(undefined);

export function TerminalProvider({ children }: { children: React.ReactNode }) {
  const [events, setEvents] = useState<MacroEvent[]>(INITIAL_EVENTS);
  const [activeEventId, setActiveEventId] = useState<string>('cpi-2026-09');
  const [operatingMode, setOperatingMode] = useState<OperatingMode>('PAPER');
  const [settings, setSettings] = useState<SettingsState>(INITIAL_SETTINGS);
  const [decisions, setDecisions] = useState<Decision[]>(INITIAL_DECISIONS);
  const [trades, setTrades] = useState<Trade[]>(INITIAL_TRADES);
  const [agentStatus, setAgentStatus] = useState<AgentState>('MONITORING');
  const [isSimulating, setIsSimulating] = useState(false);
  const [isConfirmingExecution, setIsConfirmingExecution] = useState(false);
  const [isSimModalOpen, setIsSimModalOpen] = useState(false);

  const [tradeTape, setTradeTape] = useState<LiveTapeItem[]>([
    { id: 'tape-1', timestamp: '08:31:06', source: 'ORDER ENGINE', event: 'BTC SHORT', mode: 'PAPER', status: 'FILLED', detail: '0.24 BTC @ $64,280' },
    { id: 'tape-2', timestamp: '08:31:05', source: 'RISK ENGINE', event: 'PORTFOLIO RISK', mode: 'PAPER', status: 'PASSED', detail: 'Risk 0.6% ($150) cleared' },
    { id: 'tape-3', timestamp: '08:31:04', source: 'NOVA', event: 'US CPI BIAS', mode: 'PAPER', status: 'EXECUTED', detail: 'Macro hawkish confirmed' },
    { id: 'tape-4', timestamp: '08:30:02', source: 'MACRO DETECTOR', event: 'US CPI 3.1%', mode: 'PAPER', status: 'ANALYZED', detail: '+20 bps surprise' },
  ]);

  const [agentTrace, setAgentTrace] = useState<AgentTraceStep[]>([
    { id: 'tr-1', timestamp: '08:30:01', phase: 'EVENT DETECTED', detail: 'US CPI YoY printed 3.1% vs 2.9% expected', status: 'INFO' },
    { id: 'tr-2', timestamp: '08:30:02', phase: 'SURPRISE CALCULATED', detail: '+0.2% (+20 bps) hawkish deviation from consensus', status: 'PASSED' },
    { id: 'tr-3', timestamp: '08:30:03', phase: 'MACRO MODEL', detail: 'Persistent services inflation triggers higher-for-longer expectation', status: 'INFO' },
    { id: 'tr-4', timestamp: '08:30:04', phase: 'POLICY IMPACT', detail: 'Fed rate easing delayed; real interest yields repricing upward', status: 'INFO' },
    { id: 'tr-5', timestamp: '08:30:05', phase: 'MARKET IMPACT', detail: 'Risk-off impulse: DXY +0.55%, NASDAQ -1.1%, BTC risk beta active', status: 'INFO' },
    { id: 'tr-6', timestamp: '08:30:06', phase: 'BTC SIGNAL', detail: 'Bearish momentum established with negative delta absorption', status: 'PASSED' },
    { id: 'tr-7', timestamp: '08:30:07', phase: 'RISK ENGINE', detail: '5 of 5 safety gates passed. Sized to 0.6% portfolio risk ($150 loss ceiling)', status: 'PASSED' },
    { id: 'tr-8', timestamp: '08:30:08', phase: 'DECISION', detail: 'ACTION: SHORT BTC/USDT at $64,280 | Target: $60,870 | Stop: $65,700', status: 'FINAL' },
  ]);

  const activeEvent = useMemo(() => {
    return events.find((e) => e.id === activeEventId) || events[0];
  }, [events, activeEventId]);

  // Compute portfolio values
  const portfolio = useMemo<PortfolioState>(() => {
    const equity = 25000;
    const openTrades = trades.filter((t) => t.status === 'OPEN');
    const openRisk = openTrades.reduce((acc, t) => acc + (settings.maxTradeRiskPercent * 0.6), 0);
    const dailyPnL = trades.reduce((acc, t) => acc + t.pnlUsd, 0);
    const availableCapital = equity - openTrades.reduce((acc, t) => acc + (t.quantity * t.entry), 0) + dailyPnL;
    const riskUtilization = Math.round((openRisk / settings.dailyLossLimitPercent) * 100);

    return {
      equity: equity + dailyPnL,
      availableCapital: Math.max(0, availableCapital),
      dailyPnL,
      openRisk: Number(openRisk.toFixed(2)),
      riskLimit: settings.dailyLossLimitPercent,
      riskUtilization: Math.min(100, riskUtilization),
      positions: trades,
      allocations: [
        { asset: 'BTC', weight: 42, riskUsd: 150 },
        { asset: 'ETH', weight: 18, riskUsd: 65 },
        { asset: 'TOKENIZED EQUITIES', weight: 15, riskUsd: 45 },
        { asset: 'CASH', weight: 25, riskUsd: 0 },
      ],
    };
  }, [trades, settings]);

  // Evaluate current active decision & risk gate
  const { decision: activeDecision, riskMetrics, riskGates, executionReady, blockReason } = useMemo(() => {
    return evaluateEventReasoning(activeEvent, settings, portfolio.openRisk);
  }, [activeEvent, settings, portfolio.openRisk]);

  const selectEvent = (id: string) => {
    setActiveEventId(id);
    const ev = events.find((e) => e.id === id);
    if (ev) {
      setAgentStatus('ANALYZING');
      setTimeout(() => {
        setAgentStatus('READY');
      }, 250);
    }
  };

  const updateSettings = (newSettings: Partial<SettingsState>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const executeTrade = () => {
    if (!executionReady || activeDecision.action === 'WAIT') return;

    setAgentStatus('EXECUTING');

    const newTrade: Trade = {
      id: `trd-${Date.now().toString().slice(-4)}`,
      decisionId: activeDecision.id,
      eventTitle: activeEvent.title,
      asset: activeDecision.asset,
      side: activeDecision.action === 'SHORT' ? 'SHORT' : 'LONG',
      entry: activeDecision.entry,
      quantity: Number((activeDecision.positionSize / activeDecision.entry).toFixed(4)),
      currentPrice: activeDecision.entry,
      stop: activeDecision.stop,
      target: activeDecision.target,
      mode: operatingMode,
      status: 'OPEN',
      pnlUsd: 0,
      pnlPercent: 0,
      timestamp: new Date().toLocaleTimeString('en-GB'),
    };

    const newTapeItem: LiveTapeItem = {
      id: `tape-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB'),
      source: 'ORDER ENGINE',
      event: `${activeDecision.asset} ${activeDecision.action}`,
      mode: operatingMode,
      status: 'FILLED',
      detail: `${newTrade.quantity} @ $${activeDecision.entry.toLocaleString()} [RISK ${activeDecision.riskPercent}%]`,
    };

    const newRiskTape: LiveTapeItem = {
      id: `tape-${Date.now()}-risk`,
      timestamp: new Date().toLocaleTimeString('en-GB'),
      source: 'RISK ENGINE',
      event: 'GATE PASSED',
      mode: operatingMode,
      status: 'CLEARED',
      detail: `Max loss capped at $${riskMetrics.expectedLossUsd}`,
    };

    setTimeout(() => {
      setTrades((prev) => [newTrade, ...prev]);
      setTradeTape((prev) => [newTapeItem, newRiskTape, ...prev]);
      setDecisions((prev) => [
        {
          ...activeDecision,
          status: 'EXECUTED',
        },
        ...prev,
      ]);
      setAgentStatus('EXECUTED');
      setIsConfirmingExecution(false);
    }, 200);
  };

  const rejectSignal = () => {
    const rejectTape: LiveTapeItem = {
      id: `tape-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB'),
      source: 'NOVA',
      event: `${activeDecision.asset} ${activeDecision.action}`,
      mode: operatingMode,
      status: 'REJECTED',
      detail: 'Signal declined by operator',
    };

    setTradeTape((prev) => [rejectTape, ...prev]);
    setAgentStatus('MONITORING');
    setIsConfirmingExecution(false);
  };

  const closePosition = (tradeId: string) => {
    setTrades((prev) =>
      prev.map((t) => {
        if (t.id === tradeId) {
          return {
            ...t,
            status: 'CLOSED',
            pnlUsd: t.pnlUsd || 140,
            pnlPercent: t.pnlPercent || 1.1,
          };
        }
        return t;
      })
    );

    const closeTape: LiveTapeItem = {
      id: `tape-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString('en-GB'),
      source: 'ORDER ENGINE',
      event: 'POSITION CLOSED',
      mode: operatingMode,
      status: 'CLOSED',
      detail: `Closed position ${tradeId}`,
    };

    setTradeTape((prev) => [closeTape, ...prev]);
  };

  const triggerSimulation = async (customEvent: Partial<MacroEvent>) => {
    setIsSimulating(true);
    setAgentStatus('ANALYZING');

    const newEvent: MacroEvent = {
      id: `sim-${Date.now()}`,
      time: new Date().toLocaleTimeString('en-GB'),
      date: '10 SEP 2026',
      title: customEvent.title || 'CUSTOM MACRO RELEASE',
      category: customEvent.category || 'INFLATION',
      actual: customEvent.actual || '3.4%',
      actualNum: customEvent.actualNum ?? 3.4,
      expected: customEvent.expected || '3.0%',
      expectedNum: customEvent.expectedNum ?? 3.0,
      previous: customEvent.previous || '2.9%',
      previousNum: customEvent.previousNum ?? 2.9,
      surprise: `${(customEvent.actualNum ?? 3.4) >= (customEvent.expectedNum ?? 3.0) ? '+' : ''}${((customEvent.actualNum ?? 3.4) - (customEvent.expectedNum ?? 3.0)).toFixed(1)}%`,
      surpriseNum: (customEvent.actualNum ?? 3.4) - (customEvent.expectedNum ?? 3.0),
      unit: customEvent.unit || '%',
      importance: customEvent.importance || 'CRITICAL',
      status: 'ANALYZED',
      headlineStatement: ((customEvent.actualNum ?? 3.4) > (customEvent.expectedNum ?? 3.0))
        ? 'SURPRISE ABOVE EXPECTATION'
        : ((customEvent.actualNum ?? 3.4) < (customEvent.expectedNum ?? 3.0))
        ? 'SURPRISE BELOW EXPECTATION'
        : 'IN LINE WITH CONSENSUS',
      macroBias: ((customEvent.actualNum ?? 3.4) > (customEvent.expectedNum ?? 3.0))
        ? 'RESTRICTIVE / HAWKISH'
        : ((customEvent.actualNum ?? 3.4) < (customEvent.expectedNum ?? 3.0))
        ? 'ACCOMMODATIVE / DOVISH'
        : 'NEUTRAL HOLD',
      summary: `Real-time simulation executed for ${customEvent.title || 'macro event'}. The print deviates from expectation, activating macro transmission models.`,
      economicTransmission: 'Surprise filters through discount rates, yield curves, and risk-appetite parameters across major crypto and equity indexes.',
      assetBias: [
        {
          asset: 'BTC/USDT',
          bias: ((customEvent.actualNum ?? 3.4) > (customEvent.expectedNum ?? 3.0)) ? 'BEARISH' : 'BULLISH',
          impact: 'HIGH',
          confidence: 84,
          rationale: 'Speculative beta sensitive to liquidity adjustments.',
        },
        {
          asset: 'USD / DXY',
          bias: ((customEvent.actualNum ?? 3.4) > (customEvent.expectedNum ?? 3.0)) ? 'BULLISH' : 'BEARISH',
          impact: 'HIGH',
          confidence: 86,
          rationale: 'Front-end interest differential alignment.',
        },
      ],
    };

    // Append to events list
    setEvents((prev) => [newEvent, ...prev]);
    setActiveEventId(newEvent.id);

    // Progressive agent trace
    setAgentTrace([
      { id: `tr-${Date.now()}-1`, timestamp: new Date().toLocaleTimeString('en-GB'), phase: 'EVENT DETECTED', detail: `${newEvent.title}: Actual ${newEvent.actual} vs Exp ${newEvent.expected}`, status: 'INFO' },
      { id: `tr-${Date.now()}-2`, timestamp: new Date().toLocaleTimeString('en-GB'), phase: 'SURPRISE ENGINE', detail: `Deviates by ${newEvent.surprise}. Statistical significance registered`, status: 'PASSED' },
      { id: `tr-${Date.now()}-3`, timestamp: new Date().toLocaleTimeString('en-GB'), phase: 'MACRO INTERPRETATION', detail: newEvent.macroBias, status: 'INFO' },
      { id: `tr-${Date.now()}-4`, timestamp: new Date().toLocaleTimeString('en-GB'), phase: 'RISK GATE', detail: 'Evaluating 5 independent gate criteria...', status: 'PASSED' },
    ]);

    setTimeout(() => {
      setAgentStatus('READY');
      setIsSimulating(false);
      setIsSimModalOpen(false);
    }, 450);
  };

  const resetToDefault = () => {
    setEvents(INITIAL_EVENTS);
    setActiveEventId('cpi-2026-09');
    setDecisions(INITIAL_DECISIONS);
    setTrades(INITIAL_TRADES);
    setSettings(INITIAL_SETTINGS);
  };

  return (
    <TerminalContext.Provider
      value={{
        events,
        activeEvent,
        selectEvent,
        operatingMode,
        setOperatingMode,
        settings,
        updateSettings,
        decisions,
        activeDecision,
        riskMetrics,
        riskGates,
        executionReady,
        blockReason,
        portfolio,
        tradeTape,
        agentTrace,
        agentStatus,
        isSimulating,
        isConfirmingExecution,
        setIsConfirmingExecution,
        isSimModalOpen,
        setIsSimModalOpen,
        executeTrade,
        rejectSignal,
        closePosition,
        triggerSimulation,
        resetToDefault,
      }}
    >
      {children}
    </TerminalContext.Provider>
  );
}

export function useTerminal() {
  const context = useContext(TerminalContext);
  if (!context) {
    throw new Error('useTerminal must be used within a TerminalProvider');
  }
  return context;
}
