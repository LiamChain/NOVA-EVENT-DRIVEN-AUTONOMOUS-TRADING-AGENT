'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowUpRight, ArrowDownRight, Minus, ArrowRight, Filter } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function EventsPage() {
  const { events, selectEvent } = useTerminal();
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  const categories = ['ALL', 'INFLATION', 'CENTRAL BANK', 'LABOR', 'GROWTH'];

  const filteredEvents = events.filter((evt) => {
    if (categoryFilter === 'ALL') return true;
    return evt.category === categoryFilter;
  });

  return (
    <div className="space-y-8 pb-12">
      {/* Page Header */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              GLOBAL MACRO INDEX
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              EVENTS
            </h1>
          </div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
            <span>HISTORICAL & LIVE MONITORED RELEASES</span>
          </div>
        </div>
      </div>

      {/* Category Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-black pb-4">
        <div className="flex items-center gap-1 font-mono text-xs">
          <Filter className="w-3.5 h-3.5 text-black mr-2" />
          <span className="text-muted-foreground uppercase mr-2">CATEGORY:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-3 py-1 uppercase tracking-wider font-bold border transition-colors ${
                categoryFilter === cat
                  ? 'bg-black text-white border-black'
                  : 'bg-white text-black border-transparent hover:border-black'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <span className="font-mono text-xs text-muted-foreground uppercase">
          SHOWING {filteredEvents.length} OF {events.length} EVENTS
        </span>
      </div>

      {/* Events Table */}
      <div className="border-2 border-black bg-white">
        <table className="w-full text-left font-mono text-xs border-collapse">
          <thead>
            <tr className="border-b-2 border-black text-muted-foreground uppercase text-[10px] tracking-widest bg-muted/20">
              <th className="py-4 px-4">DATE & TIME</th>
              <th className="py-4 px-4">EVENT NAME</th>
              <th className="py-4 px-4">CATEGORY</th>
              <th className="py-4 px-4 text-right">ACTUAL</th>
              <th className="py-4 px-4 text-right">EXPECTED</th>
              <th className="py-4 px-4 text-right">SURPRISE</th>
              <th className="py-4 px-4 text-center">IMPORTANCE</th>
              <th className="py-4 px-4 text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-black/10">
            {filteredEvents.map((evt) => {
              const isSurprisePositive = evt.surpriseNum > 0;
              const isSurpriseNegative = evt.surpriseNum < 0;

              return (
                <tr
                  key={evt.id}
                  className="hover:bg-muted/30 transition-colors"
                >
                  <td className="py-4 px-4 whitespace-nowrap text-muted-foreground">
                    <div>{evt.date}</div>
                    <div className="text-[10px]">{evt.time} UTC</div>
                  </td>
                  <td className="py-4 px-4 font-bold text-black text-sm">
                    <Link href={`/events/${evt.id}`} className="hover:underline flex items-center gap-1">
                      <span>{evt.title}</span>
                    </Link>
                  </td>
                  <td className="py-4 px-4">
                    <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                      {evt.category}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right font-bold text-black whitespace-nowrap">
                    {evt.actual}
                  </td>
                  <td className="py-4 px-4 text-right text-muted-foreground whitespace-nowrap">
                    {evt.expected}
                  </td>
                  <td className="py-4 px-4 text-right font-bold whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 justify-end">
                      {evt.surprise}
                      {isSurprisePositive && <ArrowUpRight className="w-3 h-3" />}
                      {isSurpriseNegative && <ArrowDownRight className="w-3 h-3" />}
                      {!isSurprisePositive && !isSurpriseNegative && <Minus className="w-3 h-3" />}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-center">
                    <span className="inline-block px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider border border-black bg-black text-white">
                      {evt.importance}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-2">
                      <Link
                        href={`/events/${evt.id}`}
                        className="px-2.5 py-1 border border-black text-black hover:bg-muted font-bold"
                      >
                        VIEW DETAIL
                      </Link>
                      <Link
                        href="/terminal"
                        onClick={() => selectEvent(evt.id)}
                        className="px-2.5 py-1 bg-black text-white border border-black hover:bg-white hover:text-black font-bold"
                      >
                        LOAD IN TERMINAL →
                      </Link>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
