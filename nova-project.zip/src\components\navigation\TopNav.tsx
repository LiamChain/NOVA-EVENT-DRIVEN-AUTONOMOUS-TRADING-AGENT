'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTerminal } from '@/context/TerminalContext';
import { Menu, X, Play, ShieldAlert, Cpu } from 'lucide-react';

export function TopNav() {
  const pathname = usePathname();
  const { operatingMode, setOperatingMode, agentStatus, setIsSimModalOpen } = useTerminal();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: '/terminal', label: 'TERMINAL' },
    { href: '/events', label: 'EVENTS' },
    { href: '/decisions', label: 'DECISIONS' },
    { href: '/portfolio', label: 'PORTFOLIO' },
    { href: '/replay', label: 'REPLAY' },
    { href: '/settings', label: 'SETTINGS' },
  ];

  return (
    <header className="border-b-2 border-black bg-white sticky top-0 z-40">
      <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Left */}
          <div className="flex items-center gap-6">
            <Link href="/" className="flex flex-col group">
              <span className="font-display text-3xl font-black tracking-tight text-black group-hover:underline">
                NOVA
              </span>
              <span className="font-mono text-[9px] uppercase tracking-widest text-muted-foreground -mt-1">
                EVENT-DRIVEN INTELLIGENCE
              </span>
            </Link>

            <div className="hidden xl:flex items-center gap-2 pl-4 border-l border-black/20 text-xs font-mono">
              <span className="w-2 h-2 bg-black inline-block animate-pulse" />
              <span className="font-semibold uppercase tracking-wider">SYSTEM ONLINE</span>
              <span className="text-muted-foreground">|</span>
              <span className="text-muted-foreground uppercase">{agentStatus}</span>
            </div>
          </div>

          {/* Center Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const isActive = pathname === link.href || (link.href !== '/' && pathname?.startsWith(link.href));
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-2 text-xs font-mono tracking-widest uppercase transition-colors border ${
                    isActive
                      ? 'bg-black text-white border-black font-bold'
                      : 'text-black border-transparent hover:border-black'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Right Tools & Mode */}
          <div className="hidden sm:flex items-center gap-3">
            {/* Simulation Trigger Button */}
            <button
              onClick={() => setIsSimModalOpen(true)}
              className="flex items-center gap-2 px-3 py-2 text-xs font-mono font-bold tracking-widest uppercase bg-black text-white border border-black hover:bg-white hover:text-black transition-colors"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>SIMULATE EVENT</span>
            </button>

            {/* Operating Mode Selector */}
            <div className="flex items-center border border-black p-0.5 text-[11px] font-mono">
              {(['SIMULATION', 'PAPER', 'LIVE'] as const).map((mode) => {
                const isSelected = operatingMode === mode;
                return (
                  <button
                    key={mode}
                    onClick={() => {
                      if (mode === 'LIVE') {
                        const ok = confirm('CAUTION: Switch to LIVE institutional execution mode? Real capital safeguards apply.');
                        if (ok) setOperatingMode(mode);
                      } else {
                        setOperatingMode(mode);
                      }
                    }}
                    className={`px-2.5 py-1 tracking-wider uppercase transition-colors ${
                      isSelected
                        ? 'bg-black text-white font-bold'
                        : 'text-black hover:bg-muted'
                    }`}
                  >
                    {mode}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setIsSimModalOpen(true)}
              className="p-2 text-xs font-mono font-bold bg-black text-white border border-black"
            >
              SIMULATE
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 border border-black text-black"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-black bg-white p-4">
          <div className="flex flex-col gap-2">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`p-3 text-xs font-mono tracking-widest uppercase border ${
                    isActive ? 'bg-black text-white border-black font-bold' : 'border-border-light text-black'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            
            <div className="mt-4 pt-4 border-t border-black/20 flex flex-col gap-3">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                OPERATING MODE
              </span>
              <div className="grid grid-cols-3 gap-1 text-xs font-mono">
                {(['SIMULATION', 'PAPER', 'LIVE'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => {
                      setOperatingMode(mode);
                      setMobileMenuOpen(false);
                    }}
                    className={`py-2 text-center uppercase border ${
                      operatingMode === mode
                        ? 'bg-black text-white border-black font-bold'
                        : 'border-border-light text-black'
                    }`}
                  >
                    {mode}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
