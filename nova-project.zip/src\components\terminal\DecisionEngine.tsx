'use client';

import React, { useState } from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ChevronDown, ChevronUp, HelpCircle, ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export function DecisionEngine() {
  const { activeDecision, executionReady } = useTerminal();
  const [whyExpanded, setWhyExpanded] = useState(false);

  const isWait = activeDecision.action === 'WAIT';
  const isShort = activeDecision.action === 'SHORT';
  const isLong = activeDecision.action === 'LONG';

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      {/* Component Header */}
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            NOVA DECISION
          </h2>
        </div>
        <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground flex items-center gap-3">
          <span>AI REASONING CORE</span>
          <span className="border border-black px-2 py-0.5 text-black font-bold">
            {activeDecision.timeHorizon}
          </span>
        </div>
      </div>

      {/* Primary Action Card */}
      <div
        className={`border-4 border-black p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 ${
          isWait ? 'bg-white text-black' : 'bg-black text-white'
        }`}
      >
        <div>
          <span
            className={`font-mono text-xs uppercase tracking-widest block mb-1 font-bold ${
              isWait ? 'text-muted-foreground' : 'text-white/70'
            }`}
          >
            RECOMMENDED AUTONOMOUS ACTION
          </span>
          <div className="flex items-baseline gap-4">
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight leading-none">
              {activeDecision.action}
            </h1>
            <span
              className={`font-mono text-xl sm:text-2xl font-bold uppercase ${
                isWait ? 'text-black' : 'text-white'
              }`}
            >
              {activeDecision.asset}
            </span>
          </div>

          <p
            className={`font-body text-sm mt-3 max-w-xl leading-relaxed ${
              isWait ? 'text-black/80' : 'text-white/80'
            }`}
          >
            {isWait
              ? (activeDecision.reasoning.waitReason || 'Market conditions fail to present a verifiable statistical asymmetry.')
              : activeDecision.reasoning.rationale}
          </p>
        </div>

        {/* Big Verdict Pill / Statement */}
        <div className="flex flex-col items-start md:items-end w-full md:w-auto pt-4 md:pt-0 border-t md:border-t-0 border-current/20">
          <span
            className={`font-mono text-[10px] uppercase tracking-widest block mb-1 ${
              isWait ? 'text-muted-foreground' : 'text-white/70'
            }`}
          >
            SYSTEM VERDICT
          </span>
          <div
            className={`font-display text-4xl sm:text-5xl font-black uppercase tracking-tight px-4 py-2 border-2 ${
              isWait
                ? 'bg-black text-white border-black'
                : 'bg-white text-black border-white'
            }`}
          >
            {isWait ? 'WAIT' : 'EXECUTE'}
          </div>
          <span
            className={`font-mono text-xs uppercase tracking-wider mt-2 font-bold ${
              isWait ? 'text-muted-foreground' : 'text-white/80'
            }`}
          >
            CONFIDENCE: {activeDecision.confidence}%
          </span>
        </div>
      </div>

      {/* Diagnostics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-0 mt-6 border border-black divide-y sm:divide-y-0 sm:divide-x divide-black bg-white">
        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            SIGNAL STRENGTH
          </span>
          <div className="font-mono text-xl font-black text-black">
            {activeDecision.reasoning.signalStrength}%
          </div>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            EVENT SURPRISE
          </span>
          <div className="font-mono text-xl font-bold text-black">
            {activeDecision.reasoning.eventSurprise}
          </div>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            MARKET ALIGNMENT
          </span>
          <div className="font-mono text-xl font-bold text-black">
            {activeDecision.reasoning.marketAlignment}
          </div>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            VOLATILITY
          </span>
          <div className="font-mono text-xl font-bold text-black">
            {activeDecision.reasoning.volatility}
          </div>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            LIQUIDITY
          </span>
          <div className="font-mono text-xl font-bold text-black">
            {activeDecision.reasoning.liquidity}
          </div>
        </div>

        <div className="p-4">
          <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
            CONFLICTS
          </span>
          <div className="font-mono text-xl font-bold text-black">
            {activeDecision.reasoning.conflictingSignals}
          </div>
        </div>
      </div>

      {/* Expandable WHY? Institutional Proof */}
      <div className="mt-6 border border-black">
        <button
          onClick={() => setWhyExpanded(!whyExpanded)}
          className="w-full flex items-center justify-between p-4 bg-muted/40 hover:bg-muted font-mono text-xs font-bold tracking-widest uppercase text-black"
        >
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-black" />
            <span>WHY? // STRUCTURED AUDIT TRAIL</span>
          </div>
          <div className="flex items-center gap-1">
            <span>{whyExpanded ? 'COLLAPSE' : 'EXPAND'}</span>
            {whyExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </div>
        </button>

        {whyExpanded && (
          <div className="p-6 bg-white border-t border-black">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 text-xs font-mono">
              <div className="border border-black p-4">
                <span className="font-bold text-black uppercase block mb-1">01. EVENT PROOF</span>
                <p className="font-body text-xs text-black/80">{activeDecision.auditTrail.eventStep}</p>
              </div>

              <div className="border border-black p-4">
                <span className="font-bold text-black uppercase block mb-1">02. MARKET CONTEXT</span>
                <p className="font-body text-xs text-black/80">{activeDecision.auditTrail.marketStep}</p>
              </div>

              <div className="border border-black p-4">
                <span className="font-bold text-black uppercase block mb-1">03. RISK GATE</span>
                <p className="font-body text-xs text-black/80">{activeDecision.auditTrail.riskStep}</p>
              </div>

              <div className="border border-black p-4 bg-black text-white">
                <span className="font-bold text-white uppercase block mb-1">04. FINAL DIRECTIVE</span>
                <p className="font-body text-xs text-white/90">{activeDecision.auditTrail.finalDecision}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
