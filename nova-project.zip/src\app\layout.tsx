import type { Metadata } from 'next';
import { Playfair_Display, Source_Serif_4, JetBrains_Mono } from 'next/font/google';
import './globals.css';
import { TerminalProvider } from '@/context/TerminalContext';
import { TopNav } from '@/components/navigation/TopNav';
import { SimulationModal } from '@/components/terminal/SimulationModal';

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

const sourceSerif = Source_Serif_4({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'NOVA — Event-Driven Autonomous Trading Agent',
  description: 'When the event hits, NOVA moves. Institutional intelligence terminal combined with an autonomous AI decision engine.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${playfair.variable} ${sourceSerif.variable} ${jetbrainsMono.variable}`}>
      <body className="bg-white text-black min-h-screen flex flex-col selection:bg-black selection:text-white">
        <TerminalProvider>
          <TopNav />
          <main className="flex-1 w-full max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {children}
          </main>
          <SimulationModal />
          <footer className="border-t border-black mt-auto py-6 px-4 sm:px-6 lg:px-8 max-w-[1600px] mx-auto w-full">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs font-mono tracking-widest uppercase">
              <div className="flex items-center gap-3">
                <span className="inline-block w-2.5 h-2.5 bg-black" />
                <span className="font-bold">NOVA INTELLIGENCE SYSTEMS</span>
                <span className="text-muted-foreground">— WHEN THE EVENT HITS, NOVA MOVES</span>
              </div>
              <div className="flex items-center gap-6 text-muted-foreground">
                <span>VERSION: 2.4.0-PRO</span>
                <span>RISK ENGINE: STRICT ZERO-LOSS GATE</span>
                <span>PAPER ENVIRONMENT</span>
              </div>
            </div>
          </footer>
        </TerminalProvider>
      </body>
    </html>
  );
}
