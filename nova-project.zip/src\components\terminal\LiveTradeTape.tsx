'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { Terminal } from 'lucide-react';

export function LiveTradeTape() {
  const { tradeTape } = useTerminal();

  return (
    <div className="border-2 border-black bg-white p-6">
      <div className="flex items-center justify-between border-b border-black pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-black" />
          <h3 className="font-mono text-xs font-black uppercase tracking-widest text-black">
            LIVE TRADE TAPE // ASYNCHRONOUS ENGINE
          </h3>
        </div>
        <span className="font-mono text-[10px] text-muted-foreground uppercase tracking-widest">
          FEED ACTIVE
        </span>
      </div>

      <div className="space-y-2 font-mono text-xs max-h-64 overflow-y-auto pr-1">
        {tradeTape.map((item) => (
          <div
            key={item.id}
            className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 border border-black/10 hover:border-black bg-muted/20 hover:bg-white transition-colors gap-2"
          >
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                [{item.timestamp}]
              </span>
              <span className="font-bold text-black uppercase bg-black text-white px-1.5 py-0.5 text-[9px]">
                {item.source}
              </span>
              <span className="font-bold text-black uppercase">
                {item.event}
              </span>
            </div>

            <div className="flex items-center gap-3 justify-between sm:justify-end text-[11px]">
              <span className="text-muted-foreground">{item.detail}</span>
              <span className="font-bold border border-black px-1.5 py-0.5 text-[9px] uppercase">
                {item.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
