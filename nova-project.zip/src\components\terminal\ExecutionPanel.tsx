'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowRight, X, ShieldCheck, AlertCircle } from 'lucide-react';

export function ExecutionPanel() {
  const {
    operatingMode,
    setOperatingMode,
    activeDecision,
    riskMetrics,
    executionReady,
    isConfirmingExecution,
    setIsConfirmingExecution,
    executeTrade,
    rejectSignal,
  } = useTerminal();

  const isWait = activeDecision.action === 'WAIT';

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8 relative">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            EXECUTION ENGINE
          </h2>
        </div>

        {/* Mode Selector */}
        <div className="flex items-center border border-black p-0.5 text-xs font-mono">
          {(['SIMULATION', 'PAPER', 'LIVE'] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => {
                if (mode === 'LIVE') {
                  const proceed = confirm('CAUTION: Live execution triggers real exchange API order routing. Enable?');
                  if (proceed) setOperatingMode(mode);
                } else {
                  setOperatingMode(mode);
                }
              }}
              className={`px-3 py-1 uppercase tracking-wider font-bold transition-colors ${
                operatingMode === mode
                  ? 'bg-black text-white'
                  : 'text-black hover:bg-muted'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {/* Main Execution Content */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
            PENDING ORDER SPECIFICATION
          </span>
          <div className="font-display text-2xl sm:text-3xl font-black uppercase tracking-tight text-black">
            {isWait ? (
              'NO ORDER DISPATCHED — SYSTEM IN WAIT STATE'
            ) : (
              <>
                {activeDecision.action} {activeDecision.asset} @ ${activeDecision.entry.toLocaleString()}
              </>
            )}
          </div>
          <div className="font-mono text-xs text-muted-foreground mt-2 flex flex-wrap gap-4">
            <span>TARGET: ${activeDecision.target.toLocaleString()}</span>
            <span>STOP: ${activeDecision.stop.toLocaleString()}</span>
            <span>PROPOSED RISK: {activeDecision.riskPercent}%</span>
            <span>MODE: {operatingMode}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
          {isWait ? (
            <div className="px-6 py-4 border-2 border-black bg-muted font-mono text-xs font-bold uppercase tracking-widest text-muted-foreground">
              EXECUTION INACTIVE (WAIT DIRECTIVE)
            </div>
          ) : !executionReady ? (
            <div className="px-6 py-4 border-2 border-black bg-black text-white font-mono text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-white" />
              <span>EXECUTION BLOCKED BY RISK GATE</span>
            </div>
          ) : (
            <>
              <button
                onClick={() => setIsConfirmingExecution(true)}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-3 px-8 py-4 bg-black text-white border-2 border-black font-mono text-xs font-black tracking-widest uppercase hover:bg-white hover:text-black transition-colors"
              >
                <span>EXECUTE {operatingMode} TRADE</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={rejectSignal}
                className="px-6 py-4 border-2 border-black font-mono text-xs font-bold tracking-widest uppercase hover:bg-muted transition-colors text-black"
              >
                REJECT SIGNAL
              </button>
            </>
          )}
        </div>
      </div>

      {/* Confirmation Modal / Overlay */}
      {isConfirmingExecution && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white border-4 border-black max-w-lg w-full p-6 md:p-8">
            <div className="flex items-center justify-between border-b-2 border-black pb-4 mb-6">
              <div className="flex items-center gap-3">
                <span className="w-3 h-3 bg-black inline-block" />
                <h3 className="font-display text-2xl font-black uppercase tracking-tight text-black">
                  ORDER CONFIRMATION
                </h3>
              </div>
              <span className="font-mono text-xs uppercase px-2 py-0.5 bg-black text-white font-bold">
                {operatingMode}
              </span>
            </div>

            <div className="space-y-4 font-mono text-xs">
              <div className="border border-black p-4 bg-muted/40">
                <span className="text-[10px] text-muted-foreground uppercase tracking-widest block mb-1">
                  NOVA PROPOSES
                </span>
                <div className="font-display text-2xl font-black uppercase text-black">
                  {activeDecision.action} {activeDecision.asset}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="border border-black p-3">
                  <span className="text-muted-foreground text-[10px] uppercase block">ENTRY PRICE</span>
                  <span className="font-bold text-sm text-black">${activeDecision.entry.toLocaleString()}</span>
                </div>
                <div className="border border-black p-3">
                  <span className="text-muted-foreground text-[10px] uppercase block">POSITION SIZE</span>
                  <span className="font-bold text-sm text-black">${activeDecision.positionSize.toLocaleString()}</span>
                </div>
                <div className="border border-black p-3">
                  <span className="text-muted-foreground text-[10px] uppercase block">STOP LOSS</span>
                  <span className="font-bold text-sm text-black">${activeDecision.stop.toLocaleString()}</span>
                </div>
                <div className="border border-black p-3">
                  <span className="text-muted-foreground text-[10px] uppercase block">TAKE PROFIT</span>
                  <span className="font-bold text-sm text-black">${activeDecision.target.toLocaleString()}</span>
                </div>
              </div>

              <div className="border border-black p-4 bg-black text-white flex justify-between items-center">
                <div>
                  <span className="text-[10px] text-white/70 uppercase block">MAX DRAWDOWN RISK</span>
                  <span className="font-bold text-base text-white">
                    {activeDecision.riskPercent}% (${riskMetrics.expectedLossUsd})
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-white/70 uppercase block">CONFIDENCE</span>
                  <span className="font-bold text-base text-white">{activeDecision.confidence}%</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-8 flex gap-3">
              <button
                onClick={executeTrade}
                className="flex-1 py-4 bg-black text-white border-2 border-black font-mono text-xs font-black tracking-widest uppercase hover:bg-white hover:text-black transition-colors"
              >
                CONFIRM EXECUTION →
              </button>
              <button
                onClick={() => setIsConfirmingExecution(false)}
                className="px-6 py-4 border-2 border-black font-mono text-xs font-bold tracking-widest uppercase hover:bg-muted text-black transition-colors"
              >
                RETURN
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
