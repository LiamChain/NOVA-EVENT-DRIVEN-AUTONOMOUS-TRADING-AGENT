'use client';

import React from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowLeft, ArrowRight, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function DecisionDetailPage() {
  const params = useParams();
  const id = params?.id as string;
  const { decisions, events, selectEvent } = useTerminal();

  const decision = decisions.find((d) => d.id === id);

  if (!decision) {
    return (
      <div className="border-4 border-black p-12 text-center my-12 bg-white">
        <h1 className="font-display text-4xl font-black uppercase tracking-tight text-black mb-4">
          DECISION NOT FOUND
        </h1>
        <p className="font-body text-base text-muted-foreground mb-6">
          The requested decision ID was not located in the journal archive.
        </p>
        <Link
          href="/decisions"
          className="inline-flex items-center gap-2 px-6 py-3 bg-black text-white font-mono text-xs font-bold uppercase tracking-widest"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO JOURNAL</span>
        </Link>
      </div>
    );
  }

  const isWait = decision.action === 'WAIT';

  return (
    <div className="space-y-8 pb-12">
      {/* Back Link */}
      <div>
        <Link
          href="/decisions"
          className="inline-flex items-center gap-2 font-mono text-xs font-bold uppercase tracking-widest text-black hover:underline"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>RETURN TO DECISION JOURNAL</span>
        </Link>
      </div>

      {/* Header */}
      <div className="border-b-4 border-black pb-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 font-mono text-xs uppercase tracking-widest text-muted-foreground mb-2">
              <span className="w-2 h-2 bg-black inline-block" />
              <span>LOG ID: {decision.id}</span>
              <span>|</span>
              <span>TIMESTAMP: {decision.timestamp}</span>
            </div>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              {decision.action} {decision.asset}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="font-mono text-xs text-right">
              <span className="text-muted-foreground uppercase block text-[10px]">VERDICT STATUS</span>
              <span className="font-bold text-base uppercase bg-black text-white px-3 py-1 inline-block">
                {decision.status} {decision.pnl && `(${decision.pnl})`}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* The Signature Institutional Equation: EVENT * MARKET * RISK = DECISION */}
      <div className="border-4 border-black p-6 md:p-8 bg-white">
        <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-4 font-bold">
          INSTITUTIONAL AUDIT FORMULA // THREE-FACTOR CONVERGENCE
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center font-mono text-xs">
          {/* Factor 1: Event */}
          <div className="border-2 border-black p-5 bg-muted/20">
            <span className="text-[10px] text-muted-foreground uppercase block mb-1">FACTOR 01</span>
            <span className="font-display text-lg font-black uppercase text-black block mb-2">
              EVENT SHOCK
            </span>
            <p className="font-body text-xs text-black/80">{decision.auditTrail.eventStep}</p>
          </div>

          {/* Factor 2: Market */}
          <div className="border-2 border-black p-5 bg-muted/20">
            <span className="text-[10px] text-muted-foreground uppercase block mb-1">FACTOR 02</span>
            <span className="font-display text-lg font-black uppercase text-black block mb-2">
              MARKET ALIGNMENT
            </span>
            <p className="font-body text-xs text-black/80">{decision.auditTrail.marketStep}</p>
          </div>

          {/* Factor 3: Risk */}
          <div className="border-2 border-black p-5 bg-muted/20">
            <span className="text-[10px] text-muted-foreground uppercase block mb-1">FACTOR 03</span>
            <span className="font-display text-lg font-black uppercase text-black block mb-2">
              RISK GATE
            </span>
            <p className="font-body text-xs text-black/80">{decision.auditTrail.riskStep}</p>
          </div>

          {/* Result: Decision */}
          <div className="border-2 border-black p-5 bg-black text-white">
            <span className="text-[10px] text-white/70 uppercase block mb-1">SYNTHESIZED OUTCOME</span>
            <span className="font-display text-lg font-black uppercase text-white block mb-2">
              = DECISION
            </span>
            <p className="font-body text-xs text-white/90">{decision.auditTrail.finalDecision}</p>
          </div>
        </div>
      </div>

      {/* Numerical Metrics Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-0 border-2 border-black divide-x divide-y sm:divide-y-0 divide-black bg-white">
        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            CONFIDENCE SCORE
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black text-black">
            {decision.confidence}%
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            SIGNAL PROBABILITY
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            PROPOSED RISK
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-black text-black">
            {decision.riskPercent.toFixed(1)}%
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            PORTFOLIO ALLOCATION
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            ENTRY PRICE
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-bold text-black">
            {decision.entry > 0 ? `$${decision.entry.toLocaleString()}` : 'N/A'}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            ORDER LEVEL
          </span>
        </div>

        <div className="p-6">
          <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-2">
            RISK / REWARD
          </span>
          <div className="font-mono text-3xl sm:text-4xl font-bold text-black">
            {decision.riskReward}
          </div>
          <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
            ASYMMETRY RATIO
          </span>
        </div>
      </div>

      {/* Macro Chain Associated */}
      <SectionRule
        thickness={4}
        title="DETERMINISTIC CAUSAL CHAIN APPLIED"
        meta="STEP-BY-STEP TRANSMISSION"
      />

      <div className="grid grid-cols-2 md:grid-cols-6 gap-0 border border-black divide-x divide-black bg-white">
        {decision.macroChain.map((step, idx) => (
          <div key={step.label} className="p-4">
            <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block mb-1">
              0{idx + 1} — {step.label}
            </span>
            <div className="font-display text-base font-bold uppercase text-black">
              {step.value}
            </div>
            {step.subtext && (
              <span className="font-mono text-[10px] text-muted-foreground uppercase mt-1 block">
                {step.subtext}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
