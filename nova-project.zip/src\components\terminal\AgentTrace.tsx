'use client';

import React, { useState } from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { Cpu, ChevronDown, ChevronUp } from 'lucide-react';

export function AgentTrace() {
  const { agentTrace, agentStatus } = useTerminal();
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <div className="border-2 border-black bg-white p-6">
      <div className="flex items-center justify-between border-b border-black pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-black" />
          <h3 className="font-mono text-xs font-black uppercase tracking-widest text-black">
            AGENT FORENSIC TRACE // REASONING PIPELINE
          </h3>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono text-[10px] bg-black text-white px-2 py-0.5 font-bold uppercase">
            STATUS: {agentStatus}
          </span>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="font-mono text-[10px] border border-black px-2 py-0.5 uppercase hover:bg-muted"
          >
            {isCollapsed ? 'EXPAND' : 'COLLAPSE'}
          </button>
        </div>
      </div>

      {!isCollapsed && (
        <div className="space-y-2 font-mono text-xs max-h-72 overflow-y-auto pr-1">
          {agentTrace.map((step) => (
            <div
              key={step.id}
              className={`p-3 border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
                step.status === 'FINAL'
                  ? 'border-black bg-black text-white'
                  : 'border-black/20 bg-muted/20 text-black'
              }`}
            >
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-bold ${step.status === 'FINAL' ? 'text-white/70' : 'text-muted-foreground'}`}>
                  [{step.timestamp}]
                </span>
                <span className={`font-bold tracking-wider uppercase text-[11px] ${step.status === 'FINAL' ? 'text-white' : 'text-black'}`}>
                  {step.phase}
                </span>
              </div>

              <div className={`text-xs ${step.status === 'FINAL' ? 'text-white/90' : 'text-black/80'}`}>
                {step.detail}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
