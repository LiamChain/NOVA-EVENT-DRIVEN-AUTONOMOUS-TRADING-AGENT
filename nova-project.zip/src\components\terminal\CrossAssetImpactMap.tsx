'use client';

import React from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export function CrossAssetImpactMap() {
  const { activeEvent } = useTerminal();

  return (
    <div className="border-2 border-black bg-white p-6 md:p-8">
      <div className="flex items-center justify-between border-b border-black pb-4 mb-6">
        <div className="flex items-center gap-3">
          <span className="w-2.5 h-2.5 bg-black inline-block" />
          <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
            CROSS-ASSET IMPACT MATRIX
          </h2>
        </div>
        <div className="font-mono text-xs text-muted-foreground uppercase tracking-widest hidden sm:flex items-center gap-4">
          <span>CATALYST: {activeEvent.title}</span>
          <span>CORRELATION SPREAD: ACTIVE</span>
        </div>
      </div>

      {/* Center Catalyst Announcement */}
      <div className="border border-black bg-black text-white p-4 mb-6 text-center">
        <span className="font-mono text-[10px] tracking-widest uppercase text-white/70 block">
          CENTRAL SHOCK SOURCE
        </span>
        <span className="font-display text-xl sm:text-2xl font-black uppercase tracking-tight">
          {activeEvent.title} [{activeEvent.surprise}]
        </span>
      </div>

      {/* Grid of Interconnected Assets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {activeEvent.assetBias.map((item) => {
          const isHighConviction = item.confidence >= 80;
          const isBullish = item.bias === 'BULLISH';
          const isBearish = item.bias === 'BEARISH';

          return (
            <div
              key={item.asset}
              className={`border-2 p-5 flex flex-col justify-between transition-colors ${
                isHighConviction
                  ? 'border-black bg-white hover:bg-muted/30'
                  : 'border-border-light bg-muted/20 text-muted-foreground'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 border-b border-black/10 pb-3">
                  <div>
                    <span className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground block">
                      ASSET CLASS
                    </span>
                    <h3 className="font-mono text-base font-black text-black">
                      {item.asset}
                    </h3>
                  </div>

                  {/* Direction Badge */}
                  <div
                    className={`flex items-center gap-1 px-2.5 py-1 text-xs font-mono font-bold tracking-wider uppercase border ${
                      isBearish
                        ? 'bg-black text-white border-black'
                        : isBullish
                        ? 'bg-white text-black border-black'
                        : 'bg-muted text-muted-foreground border-border-light'
                    }`}
                  >
                    <span>{item.bias}</span>
                    {isBullish && <ArrowUpRight className="w-3.5 h-3.5" />}
                    {isBearish && <ArrowDownRight className="w-3.5 h-3.5" />}
                    {!isBullish && !isBearish && <Minus className="w-3.5 h-3.5" />}
                  </div>
                </div>

                {/* Narrative Rationale */}
                <p className="font-body text-xs text-black/80 mt-3 leading-relaxed">
                  {item.rationale}
                </p>
              </div>

              {/* Footer Metrics */}
              <div className="mt-4 pt-3 border-t border-black/10 flex items-center justify-between font-mono text-xs">
                <div>
                  <span className="text-[10px] text-muted-foreground uppercase block">
                    IMPACT
                  </span>
                  <span className="font-bold text-black">{item.impact}</span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-muted-foreground uppercase block">
                    CONVICTION
                  </span>
                  <span className="font-bold text-black">{item.confidence}%</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
