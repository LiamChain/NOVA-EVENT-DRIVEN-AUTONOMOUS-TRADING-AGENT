'use client';

import React, { useState } from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { ShieldAlert, Check, RotateCcw, AlertTriangle } from 'lucide-react';
import { SectionRule } from '@/components/common/SectionRule';

export default function SettingsPage() {
  const { settings, updateSettings, resetToDefault } = useTerminal();
  const [savedNotice, setSavedNotice] = useState(false);

  const handleUpdate = (key: keyof typeof settings, val: any) => {
    updateSettings({ [key]: val });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 1500);
  };

  return (
    <div className="space-y-8 pb-12 max-w-4xl">
      {/* Header */}
      <div className="border-b-4 border-black pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground block mb-1">
              SYSTEM GOVERNANCE & RISK CONTROLS
            </span>
            <h1 className="font-display text-5xl sm:text-7xl font-black uppercase tracking-tight text-black">
              SETTINGS
            </h1>
          </div>
          <div className="flex items-center gap-3">
            {savedNotice && (
              <span className="font-mono text-xs font-bold uppercase bg-black text-white px-3 py-1 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                SAVED
              </span>
            )}
            <button
              onClick={resetToDefault}
              className="flex items-center gap-1.5 px-3 py-1.5 border border-black font-mono text-xs font-bold uppercase hover:bg-muted"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RESET DEFAULTS</span>
            </button>
          </div>
        </div>
      </div>

      {/* Philosophy Callout */}
      <div className="border-2 border-black p-6 bg-muted/20">
        <div className="flex items-center gap-3 mb-2 font-mono text-xs font-bold uppercase">
          <ShieldAlert className="w-4 h-4 text-black" />
          <span>INSTITUTIONAL RISK BOUNDARIES</span>
        </div>
        <p className="font-body text-sm text-black/80 leading-relaxed">
          These guardrails govern the independent risk engine. Adjusting these parameters directly recalculates the execution gates on all active events across the terminal.
        </p>
      </div>

      {/* Settings Form */}
      <div className="border-2 border-black bg-white p-6 md:p-8 space-y-8">
        
        {/* Confidence Threshold */}
        <div className="border-b border-black/20 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
            <div>
              <label className="font-display text-xl font-bold uppercase text-black block">
                CONFIDENCE THRESHOLD
              </label>
              <span className="font-mono text-xs text-muted-foreground">
                Minimum statistical conviction required before generating LONG or SHORT directives.
              </span>
            </div>
            <div className="font-mono text-2xl font-black text-black">
              {settings.confidenceThreshold}%
            </div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <input
              type="range"
              min="50"
              max="95"
              step="1"
              value={settings.confidenceThreshold}
              onChange={(e) => handleUpdate('confidenceThreshold', parseInt(e.target.value))}
              className="w-full accent-black cursor-pointer"
            />
          </div>
        </div>

        {/* Max Trade Risk */}
        <div className="border-b border-black/20 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
            <div>
              <label className="font-display text-xl font-bold uppercase text-black block">
                MAX RISK PER TRADE
              </label>
              <span className="font-mono text-xs text-muted-foreground">
                Maximum allowable portfolio equity risk on any single macro catalyst.
              </span>
            </div>
            <div className="font-mono text-2xl font-black text-black">
              {settings.maxTradeRiskPercent.toFixed(1)}%
            </div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <input
              type="range"
              min="0.2"
              max="3.0"
              step="0.1"
              value={settings.maxTradeRiskPercent}
              onChange={(e) => handleUpdate('maxTradeRiskPercent', parseFloat(e.target.value))}
              className="w-full accent-black cursor-pointer"
            />
          </div>
        </div>

        {/* Daily Loss Limit */}
        <div className="border-b border-black/20 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
            <div>
              <label className="font-display text-xl font-bold uppercase text-black block">
                DAILY LOSS LIMIT
              </label>
              <span className="font-mono text-xs text-muted-foreground">
                Aggregate daily drawdown ceiling. System halts all orders upon breach.
              </span>
            </div>
            <div className="font-mono text-2xl font-black text-black">
              {settings.dailyLossLimitPercent.toFixed(1)}%
            </div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <input
              type="range"
              min="1.0"
              max="5.0"
              step="0.5"
              value={settings.dailyLossLimitPercent}
              onChange={(e) => handleUpdate('dailyLossLimitPercent', parseFloat(e.target.value))}
              className="w-full accent-black cursor-pointer"
            />
          </div>
        </div>

        {/* Minimum Risk/Reward Ratio */}
        <div className="border-b border-black/20 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
            <div>
              <label className="font-display text-xl font-bold uppercase text-black block">
                MINIMUM RISK / REWARD
              </label>
              <span className="font-mono text-xs text-muted-foreground">
                Trades below this asymmetry ratio are automatically routed to WAIT state.
              </span>
            </div>
            <div className="font-mono text-2xl font-black text-black">
              1 : {settings.minRiskRewardRatio.toFixed(1)}
            </div>
          </div>
          <div className="mt-4 flex items-center gap-4">
            <input
              type="range"
              min="1.5"
              max="3.5"
              step="0.1"
              value={settings.minRiskRewardRatio}
              onChange={(e) => handleUpdate('minRiskRewardRatio', parseFloat(e.target.value))}
              className="w-full accent-black cursor-pointer"
            />
          </div>
        </div>

        {/* Allow Live Execution Toggle */}
        <div className="pt-2">
          <div className="flex items-start justify-between gap-4">
            <div>
              <label className="font-display text-xl font-bold uppercase text-black block">
                ALLOW LIVE EXCHANGE EXECUTION
              </label>
              <span className="font-body text-xs text-muted-foreground mt-1 block">
                When enabled, the execution engine permits routing orders to live exchange APIs.
              </span>
            </div>

            <button
              onClick={() => {
                if (!settings.allowLiveExecution) {
                  const agree = confirm('SAFETY GATE: Live trading requires active API credentials. Enable live execution capability?');
                  if (agree) handleUpdate('allowLiveExecution', true);
                } else {
                  handleUpdate('allowLiveExecution', false);
                }
              }}
              className={`px-4 py-2 font-mono text-xs font-bold uppercase border-2 transition-colors ${
                settings.allowLiveExecution
                  ? 'bg-black text-white border-black'
                  : 'bg-white text-black border-black hover:bg-muted'
              }`}
            >
              {settings.allowLiveExecution ? 'LIVE ACTIVE' : 'LOCKED (OFF)'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
