'use client';

import React, { useState } from 'react';
import { useTerminal } from '@/context/TerminalContext';
import { X, Play, Cpu, Sparkles } from 'lucide-react';
import { MacroEvent } from '@/types';

export function SimulationModal() {
  const { isSimModalOpen, setIsSimModalOpen, triggerSimulation, isSimulating } = useTerminal();

  const [simType, setSimType] = useState<'preset' | 'custom'>('preset');
  const [selectedPreset, setSelectedPreset] = useState<string>('cpi-spike');

  // Custom event fields
  const [customTitle, setCustomTitle] = useState('US CORE PCE PRICE INDEX');
  const [customCategory, setCustomCategory] = useState<MacroEvent['category']>('INFLATION');
  const [customActual, setCustomActual] = useState(3.4);
  const [customExpected, setCustomExpected] = useState(2.8);
  const [customPrevious, setCustomPrevious] = useState(2.7);
  const [customUnit, setCustomUnit] = useState('%');

  if (!isSimModalOpen) return null;

  const presets = [
    {
      id: 'cpi-spike',
      title: 'US CPI (Inflation Spike)',
      category: 'INFLATION' as const,
      actual: '3.5%',
      actualNum: 3.5,
      expected: '3.0%',
      expectedNum: 3.0,
      previous: '2.9%',
      previousNum: 2.9,
      unit: '%',
      desc: 'Significant +50 bps inflation resurgence; hawkish trigger.',
    },
    {
      id: 'fomc-hike',
      title: 'FOMC Surprise +25bps Hike',
      category: 'CENTRAL BANK' as const,
      actual: '4.75%',
      actualNum: 4.75,
      expected: '4.50%',
      expectedNum: 4.50,
      previous: '4.50%',
      previousNum: 4.50,
      unit: '%',
      desc: 'Shock rate hike tightening macro financial conditions immediately.',
    },
    {
      id: 'ppi-cooling',
      title: 'US PPI Deflationary Beat',
      category: 'INFLATION' as const,
      actual: '1.4%',
      actualNum: 1.4,
      expected: '2.2%',
      expectedNum: 2.2,
      previous: '2.1%',
      previousNum: 2.1,
      unit: '%',
      desc: 'Rapid wholesale cost contraction; dovish easing catalyst.',
    },
    {
      id: 'nfp-blowout',
      title: 'NFP Huge Labor Beat (+120K)',
      category: 'LABOR' as const,
      actual: '295K',
      actualNum: 295,
      expected: '175K',
      expectedNum: 175,
      previous: '180K',
      previousNum: 180,
      unit: 'K',
      desc: 'Massive jobs beat postponing rate reductions.',
    },
    {
      id: 'gdp-recession',
      title: 'US GDP Negative Contraction',
      category: 'GROWTH' as const,
      actual: '-0.6%',
      actualNum: -0.6,
      expected: '1.2%',
      expectedNum: 1.2,
      previous: '1.4%',
      previousNum: 1.4,
      unit: '%',
      desc: 'Growth contraction raising stagflation and defensive flight.',
    },
  ];

  const handleRunSimulation = async () => {
    if (simType === 'preset') {
      const preset = presets.find((p) => p.id === selectedPreset) || presets[0];
      await triggerSimulation({
        title: preset.title,
        category: preset.category,
        actual: preset.actual,
        actualNum: preset.actualNum,
        expected: preset.expected,
        expectedNum: preset.expectedNum,
        previous: preset.previous,
        previousNum: preset.previousNum,
        unit: preset.unit,
        importance: 'CRITICAL',
      });
    } else {
      await triggerSimulation({
        title: customTitle,
        category: customCategory,
        actual: `${customActual}${customUnit}`,
        actualNum: customActual,
        expected: `${customExpected}${customUnit}`,
        expectedNum: customExpected,
        previous: `${customPrevious}${customUnit}`,
        previousNum: customPrevious,
        unit: customUnit,
        importance: 'HIGH',
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border-4 border-black max-w-2xl w-full p-6 md:p-8 my-8 relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-black pb-4 mb-6">
          <div className="flex items-center gap-3">
            <Cpu className="w-5 h-5 text-black" />
            <h2 className="font-display text-2xl font-black uppercase tracking-tight text-black">
              EVENT SIMULATION LAB
            </h2>
          </div>
          <button
            onClick={() => setIsSimModalOpen(false)}
            className="p-1 border border-black hover:bg-muted text-black"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Toggle: Preset vs Custom */}
        <div className="grid grid-cols-2 gap-0 border border-black mb-6 font-mono text-xs">
          <button
            onClick={() => setSimType('preset')}
            className={`py-2.5 font-bold uppercase tracking-widest transition-colors ${
              simType === 'preset' ? 'bg-black text-white' : 'bg-white text-black hover:bg-muted'
            }`}
          >
            STANDARD MACRO PRESETS
          </button>
          <button
            onClick={() => setSimType('custom')}
            className={`py-2.5 font-bold uppercase tracking-widest transition-colors ${
              simType === 'custom' ? 'bg-black text-white' : 'bg-white text-black hover:bg-muted'
            }`}
          >
            CUSTOM EVENT INJECTION
          </button>
        </div>

        {/* Preset Selection */}
        {simType === 'preset' && (
          <div className="space-y-3 mb-8">
            {presets.map((preset) => (
              <label
                key={preset.id}
                onClick={() => setSelectedPreset(preset.id)}
                className={`flex items-start justify-between p-4 border cursor-pointer transition-colors ${
                  selectedPreset === preset.id
                    ? 'border-2 border-black bg-muted/40 font-bold'
                    : 'border-border-light hover:border-black'
                }`}
              >
                <div className="pr-4">
                  <div className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="preset"
                      checked={selectedPreset === preset.id}
                      onChange={() => setSelectedPreset(preset.id)}
                      className="accent-black w-4 h-4"
                    />
                    <span className="font-display text-lg uppercase tracking-tight text-black">
                      {preset.title}
                    </span>
                  </div>
                  <p className="font-body text-xs text-muted-foreground mt-1 ml-6">
                    {preset.desc}
                  </p>
                </div>
                <div className="text-right font-mono text-xs whitespace-nowrap">
                  <div className="font-bold text-black">{preset.actual} vs {preset.expected}</div>
                  <div className="text-[10px] text-muted-foreground uppercase">{preset.category}</div>
                </div>
              </label>
            ))}
          </div>
        )}

        {/* Custom Event Builder */}
        {simType === 'custom' && (
          <div className="space-y-4 mb-8 font-mono text-xs">
            <div>
              <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                EVENT TITLE
              </label>
              <input
                type="text"
                value={customTitle}
                onChange={(e) => setCustomTitle(e.target.value)}
                className="w-full p-3 border-2 border-black focus:outline-none font-bold"
                placeholder="e.g. US CORE PCE PRICE INDEX"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                  CATEGORY
                </label>
                <select
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value as any)}
                  className="w-full p-3 border-2 border-black bg-white font-bold"
                >
                  <option value="INFLATION">INFLATION</option>
                  <option value="CENTRAL BANK">CENTRAL BANK</option>
                  <option value="LABOR">LABOR</option>
                  <option value="GROWTH">GROWTH</option>
                  <option value="EARNINGS">EARNINGS</option>
                  <option value="GEOPOLITICAL">GEOPOLITICAL</option>
                </select>
              </div>

              <div>
                <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                  METRIC UNIT
                </label>
                <input
                  type="text"
                  value={customUnit}
                  onChange={(e) => setCustomUnit(e.target.value)}
                  className="w-full p-3 border-2 border-black font-bold"
                  placeholder="%, bps, K, $"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                  ACTUAL VALUE
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={customActual}
                  onChange={(e) => setCustomActual(parseFloat(e.target.value) || 0)}
                  className="w-full p-3 border-2 border-black font-black text-base"
                />
              </div>

              <div>
                <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                  EXPECTED VALUE
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={customExpected}
                  onChange={(e) => setCustomExpected(parseFloat(e.target.value) || 0)}
                  className="w-full p-3 border-2 border-black font-bold text-base text-muted-foreground"
                />
              </div>

              <div>
                <label className="block uppercase text-[10px] font-bold text-muted-foreground mb-1">
                  PREVIOUS
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={customPrevious}
                  onChange={(e) => setCustomPrevious(parseFloat(e.target.value) || 0)}
                  className="w-full p-3 border-2 border-black font-bold text-base text-muted-foreground"
                />
              </div>
            </div>

            <div className="border border-black p-3 bg-muted/40 text-xs">
              <span className="font-bold block mb-1">CALCULATED SPREAD:</span>
              <span>
                {customActual - customExpected >= 0 ? '+' : ''}
                {(customActual - customExpected).toFixed(1)}
                {customUnit} ({Math.abs(customActual - customExpected) > 0.1 ? 'STATISTICALLY SIGNIFICANT' : 'NEUTRAL'})
              </span>
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="flex gap-3">
          <button
            onClick={handleRunSimulation}
            disabled={isSimulating}
            className="flex-1 py-4 bg-black text-white border-2 border-black font-mono text-xs font-black tracking-widest uppercase hover:bg-white hover:text-black transition-colors flex items-center justify-center gap-2"
          >
            <span>{isSimulating ? 'EVALUATING PIPELINE...' : 'TRIGGER EVENT →'}</span>
          </button>
          <button
            onClick={() => setIsSimModalOpen(false)}
            className="px-6 py-4 border-2 border-black font-mono text-xs font-bold tracking-widest uppercase hover:bg-muted text-black transition-colors"
          >
            CANCEL
          </button>
        </div>
      </div>
    </div>
  );
}
