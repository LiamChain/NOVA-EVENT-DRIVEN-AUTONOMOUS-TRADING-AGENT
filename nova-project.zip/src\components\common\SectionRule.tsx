import React from 'react';

interface SectionRuleProps {
  thickness?: 4 | 8;
  title?: string;
  meta?: string;
  className?: string;
}

export function SectionRule({
  thickness = 4,
  title,
  meta,
  className = '',
}: SectionRuleProps) {
  return (
    <div className={`my-8 ${className}`}>
      {(title || meta) && (
        <div className="flex items-center justify-between text-xs font-mono uppercase tracking-widest pb-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-black inline-block" />
            <span className="font-bold text-black">{title}</span>
          </div>
          {meta && <span className="text-muted-foreground">{meta}</span>}
        </div>
      )}
      <div className="relative flex items-center">
        <div
          className={`w-full bg-black ${thickness === 8 ? 'h-2' : 'h-1'}`}
        />
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-black border-2 border-white" />
      </div>
    </div>
  );
}
